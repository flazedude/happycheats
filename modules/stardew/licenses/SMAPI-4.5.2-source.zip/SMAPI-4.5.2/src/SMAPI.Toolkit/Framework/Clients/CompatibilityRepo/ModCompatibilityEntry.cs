using System.Collections.Generic;
using StardewModdingAPI.Toolkit.Framework.UpdateData;

namespace StardewModdingAPI.Toolkit.Framework.Clients.CompatibilityRepo;

/// <summary>A mod entry in the compatibility list.</summary>
public class ModCompatibilityEntry
{
    /*********
    ** Accessors
    *********/
    /// <summary>The mod's unique ID. If the mod has alternate/old IDs, they're listed in latest to oldest order.</summary>
    public string[] ID { get; }

    /// <summary>The mod's display name. If the mod has multiple names, the first one is the most canonical name.</summary>
    public string[] Name { get; }

    /// <summary>The mod's author name. If the author has multiple names, the first one is the most canonical name.</summary>
    public string[] Author { get; }

    /// <summary>The mod ID on Nexus.</summary>
    public int? NexusID { get; }

    /// <summary>The mod ID in the Chucklefish mod repo.</summary>
    public int? ChucklefishID { get; }

    /// <summary>The mod ID in the CurseForge mod repo.</summary>
    public int? CurseForgeID { get; }

    /// <summary>The mod ID in the ModDrop mod repo.</summary>
    public int? ModDropID { get; }

    /// <summary>The GitHub repository in the form 'owner/repo'.</summary>
    public string? GitHubRepo { get; }

    /// <summary>The URL to a non-GitHub source repo.</summary>
    public string? CustomSourceUrl { get; }

    /// <summary>The custom mod page URL (if applicable).</summary>
    public string? CustomUrl { get; }

    /// <summary>The name of the mod which loads this content pack, if applicable.</summary>
    public string? ContentPackFor { get; }

    /// <summary>The mod's compatibility with the latest stable version of the game.</summary>
    public ModCompatibilityInfo Compatibility { get; }

    /// <summary>The human-readable warnings for players about this mod, in Markdown format.</summary>
    public string[] Warnings { get; }

    /// <summary>The HTML version of <see cref="Warnings"/>, if different.</summary>
    public string[]? HtmlWarnings { get; }

    /// <summary>Special notes intended for developers who maintain unofficial updates or submit pull requests.</summary>
    public string? DevNote { get; }

    /// <summary>The data overrides to apply to the mod's manifest or remote mod page data, if any.</summary>
    public ModDataOverrideEntry? Overrides { get; }

    /// <summary>The link anchor for the mod entry in the compatibility list.</summary>
    public string? Anchor { get; }


    /*********
    ** Public methods
    *********/
    /// <summary>Construct an instance.</summary>
    /// <param name="id"><inheritdoc cref="ID" path="/summary"/></param>
    /// <param name="name"><inheritdoc cref="Name" path="/summary"/></param>
    /// <param name="author"><inheritdoc cref="Author" path="/summary"/></param>
    /// <param name="nexusId"><inheritdoc cref="NexusID" path="/summary"/></param>
    /// <param name="chucklefishId"><inheritdoc cref="ChucklefishID" path="/summary"/></param>
    /// <param name="curseForgeId"><inheritdoc cref="CurseForgeID" path="/summary"/></param>
    /// <param name="modDropId"><inheritdoc cref="ModDropID" path="/summary"/></param>
    /// <param name="githubRepo"><inheritdoc cref="GitHubRepo" path="/summary"/></param>
    /// <param name="customSourceUrl"><inheritdoc cref="CustomSourceUrl" path="/summary"/></param>
    /// <param name="customUrl"><inheritdoc cref="CustomUrl" path="/summary"/></param>
    /// <param name="contentPackFor"><inheritdoc cref="ContentPackFor" path="/summary"/></param>
    /// <param name="compatibility"><inheritdoc cref="Compatibility" path="/summary"/></param>
    /// <param name="warnings"><inheritdoc cref="Warnings" path="/summary"/></param>
    /// <param name="htmlWarnings"><inheritdoc cref="HtmlWarnings" path="/summary"/></param>
    /// <param name="devNote"><inheritdoc cref="DevNote" path="/summary"/></param>
    /// <param name="overrides"><inheritdoc cref="Overrides" path="/summary"/></param>
    /// <param name="anchor"><inheritdoc cref="Anchor" path="/summary"/></param>
    public ModCompatibilityEntry(string[] id, string[] name, string[] author, int? nexusId, int? chucklefishId, int? curseForgeId, int? modDropId, string? githubRepo, string? customSourceUrl, string? customUrl, string? contentPackFor, ModCompatibilityInfo compatibility, string[] warnings, string[]? htmlWarnings, string? devNote, ModDataOverrideEntry? overrides, string? anchor)
    {
        this.ID = id;
        this.Name = name;
        this.Author = author;
        this.NexusID = nexusId;
        this.ChucklefishID = chucklefishId;
        this.CurseForgeID = curseForgeId;
        this.ModDropID = modDropId;
        this.GitHubRepo = githubRepo;
        this.CustomSourceUrl = customSourceUrl;
        this.CustomUrl = customUrl;
        this.ContentPackFor = contentPackFor;
        this.Compatibility = compatibility;
        this.Warnings = warnings;
        this.HtmlWarnings = htmlWarnings;
        this.DevNote = devNote;
        this.Overrides = overrides;
        this.Anchor = anchor;
    }

    /// <summary>Get the web URLs for the mod pages, if any.</summary>
    public IEnumerable<KeyValuePair<ModSiteKey, string>> GetModPageUrls()
    {
        bool anyFound = false;

        // normal mod pages
        if (this.NexusID.HasValue)
        {
            anyFound = true;
            yield return new KeyValuePair<ModSiteKey, string>(ModSiteKey.Nexus, $"https://www.nexusmods.com/stardewvalley/mods/{this.NexusID}");
        }
        if (this.ModDropID.HasValue)
        {
            anyFound = true;
            yield return new KeyValuePair<ModSiteKey, string>(ModSiteKey.ModDrop, $"https://www.moddrop.com/stardew-valley/mod/{this.ModDropID}");
        }
        if (this.CurseForgeID.HasValue)
        {
            anyFound = true;
            yield return new KeyValuePair<ModSiteKey, string>(ModSiteKey.CurseForge, $"https://www.curseforge.com/projects/{this.CurseForgeID}");
        }
        if (this.ChucklefishID.HasValue)
        {
            anyFound = true;
            yield return new KeyValuePair<ModSiteKey, string>(ModSiteKey.Chucklefish, $"https://community.playstarbound.com/resources/{this.ChucklefishID}");
        }

        // custom URL
        if (!anyFound && !string.IsNullOrWhiteSpace(this.CustomUrl))
        {
            anyFound = true;
            yield return new KeyValuePair<ModSiteKey, string>(ModSiteKey.Unknown, this.CustomUrl);
        }

        // fallback
        if (!anyFound && !string.IsNullOrWhiteSpace(this.GitHubRepo))
            yield return new KeyValuePair<ModSiteKey, string>(ModSiteKey.GitHub, $"https://github.com/{this.GitHubRepo}/releases");
    }

    /// <summary>Get whether this compatibility entry refers to the given mod site page ID.</summary>
    /// <param name="site">The mod site.</param>
    /// <param name="id">The mod page ID.</param>
    public bool HasSiteId(ModSiteKey site, int id)
    {
        return site switch
        {
            ModSiteKey.Chucklefish => this.ChucklefishID == id,
            ModSiteKey.CurseForge => this.CurseForgeID == id,
            ModSiteKey.ModDrop => this.ModDropID == id,
            ModSiteKey.Nexus => this.NexusID == id,
            _ => false
        };
    }
}
