← [README](README.md)

# Release notes
## 4.0.0 and later
See [newer release notes](release-notes.md).

## 3.18.6
Released 05 October 2023 for Stardew Valley 1.5.6 or later.

* For players:
  * Fixed SpriteMaster compatibility in SMAPI 3.18.5+ with temporary workaround.
  * Fixed `player_add` and `list_items` console commands not including Pickled Ginger, and returning Honey instead of Wild Honey _(in Console Commands)_.

* For mod authors:
  * Added asset propagation for `LooseSprites/chatBox` and `LooseSprites/emojis`.

* For the web UI:
  * Fixed uploaded log/JSON file expiry alway shown as renewed.

## 3.18.5
Released 26 August 2023 for Stardew Valley 1.5.6 or later.

* For players:
  * Reduced startup time when many mods are rewritten for compatibility.
  * Fixed app icon on Linux/macOS, and for some players on Windows (thanks to Datrio!).
  * Fixed error if you copy a null field into `config.user.json`.
  * Fixed installer creating a "null" file in its folder.
  * Fixed installer moving bundled mods back to their default location on update. It now correctly updates their existing folder instead.

* For mod authors:
  * Updated dependencies, including [Mono.Cecil](https://github.com/jbevain/cecil) 0.11.4 → 0.11.5 (see [changes](https://github.com/jbevain/cecil/releases/tag/0.11.5)).
  * Fixed NPC warp cache not updated when a map edit changes door warps (thanks to atravita!).

* For the web UI:
  * Viewing an uploaded log/JSON file within 15 days of expiry now auto-renews it, to allow for discussions that last longer than the default 30-day expiry.
  * Fixed log parser's summary skipping mods if some have no description.
  * Fixed log parser no longer ignoring Error Handler in newer SMAPI-on-Android versions (thanks to AnotherPillow!).

* For SMAPI developers:
  * Overhauled compatibility rewriters.  
    _This allows simpler, more robust, and more flexible crossplatform rewrites (e.g. on Android) and prepares for the upcoming Stardew Valley 1.6. See remarks on the new `ReplaceReferencesRewriter` for more info._

## 3.18.4
Released 24 June 2023 for Stardew Valley 1.5.6 or later.

* For players:
  * In multiplayer, the game/SMAPI window titles now show whether you're the main player or a farmhand.
  * The `test_input` console command now logs input until the command is run again (instead of for 30 seconds).
  * Fixed logged SMAPI errors not having line numbers on Linux/macOS.
  * Fixed wezterm terminal support on Linux/macoS (thanks to romangraef!).
  * Fixed install error if a game folder has an invalid symlink.

* For mod authors:
  * Added `--no-prompt` installer command-line argument for automated tools (thanks to NyCodeGHG!).
  * Added clearer error message when a map tilesheet has no image source (thanks to atravita!).
  * Fixed `Context.HasRemotePlayers` being true when there's no farmhands connected.
  * Fixed error loading a mod if it explicitly sets `"MinimumApiVersion": null`.
  * Updated Newtonsoft.Json 13.0.2 → 13.0.3 (see [changes](https://github.com/JamesNK/Newtonsoft.Json/releases/tag/13.0.3)) and Pintail 2.2.2 → 2.3.0 (see [changes](https://github.com/Nanoray-pl/Pintail/blob/master/docs/release-notes.md#230)).

* For SMAPI toolkit users:
  * Fixed `ModFolder` not being JSON-serializable.

* For the web API:
  * Fixed manifest schema format for the `examples` field (thanks to boneskull!).

## 3.18.3
Released 09 April 2023 for Stardew Valley 1.5.6 or later.

* For players:
  * Fixed `findstr` installer error for some players.
  * Fixed installer error for some Linux players due to a non-portable shebang (thanks to freyacoded!).
  * Fixed error using load order overrides when there are broken mods installed (thanks to atravita!).
  * Removed `LargeAddressAware` flag on SMAPI (no longer needed since it's 64-bit now).
  * Improved translations. Thanks to stylemate (updated Korean)!

* For mod authors:
  * Added `IsActiveForScreen()` method to `PerScreen<T>`.
  * Updated to [FluentHttpClient](https://github.com/Pathoschild/FluentHttpClient#readme) 4.3.0 (see [changes](https://github.com/Pathoschild/FluentHttpClient/blob/develop/RELEASE-NOTES.md#430)).
  * Adjusted `ModContentManager.HandleUnknownFileType` to let mods patch it.
  * Fixed `Context.IsWorldReady` being editable by mods.

* For the web UI:
  * Updated the JSON validator/schema for Content Patcher 1.29.0.

## 3.18.2
Released 09 January 2023 for Stardew Valley 1.5.6 or later.

* For players:
  * Fixed empty save backups for some macOS players.
  * Fixed `player_add` console command not handling custom slingshots correctly (thanks to DaLion!).

* For mod authors:
  * Added `DelegatingModHooks` utility for mods which need to override SMAPI's mod hooks directly.
  * Updated to Newtonsoft.Json 13.0.2 (see [changes](https://github.com/JamesNK/Newtonsoft.Json/releases/tag/13.0.2)) and Pintail 2.2.2 (see [changes](https://github.com/Nanoray-pl/Pintail/blob/master/docs/release-notes.md#222)).

## 3.18.1
Released 01 December 2022 for Stardew Valley 1.5.6 or later.

* For players:
  * Fixed mod texture edits sometimes cut off (thanks to atravita!).

* For the web UI:
  * The log parser no longer warns about missing Error Handler on Android, where it doesn't exist yet (thanks to AnotherPillow!).

## 3.18.0
Released 12 November 2022 for Stardew Valley 1.5.6 or later. See [release highlights](https://www.patreon.com/posts/74565278).

* For players:
  * You can now override the mod load order in `smapi-internal/config.json` (thanks to Shockah!).
  * You can now disable console input in `smapi-internal/config.json`, which may reduce CPU usage on some Linux systems.
  * Fixed map edits not always applied for farmhands in multiplayer (thanks to SinZ163!).
  * Internal changes to prepare for the upcoming Stardew Valley 1.6 and SMAPI 4.0.

* For mod authors:
  * Optimized asset name comparisons (thanks to atravita!).
  * Raised all deprecation messages to the 'pending removal' level.
  * **This is the last major update before SMAPI 4.0.0, which will drop all deprecated APIs.** If you haven't [fixed deprecation warnings in your mod code](https://stardewvalleywiki.com/Modding:Migrate_to_SMAPI_4.0) (if any), you should do it soon. SMAPI 4.0.0 will release alongside the upcoming Stardew Valley 1.6.

* For the web UI:
  * The log parser now detects split-screen mode and shows which screen logged each message.

## 3.17.2
Released 21 October 2022 for Stardew Valley 1.5.6 or later.

* For players:
  * Fixed installer crash if Steam's library data is invalid or in an old format; it'll now be ignored instead.
* For mod authors:
  * Fixed image patches sometimes applied one pixel higher than expected after 3.17.0 (thanks to atravita!).

## 3.17.1
Released 10 October 2022 for Stardew Valley 1.5.6 or later.

* For players:
  * Fixed installer error on Windows if the Steam library folder exists but doesn't contain Steam's `.vdf` library data file.

## 3.17.0
Released 09 October 2022 for Stardew Valley 1.5.6 or later. See [release highlights](https://www.patreon.com/posts/73090322).

* For players:
  * You can now download SMAPI 'strict mode' from [Nexus files](https://www.nexusmods.com/stardewvalley/mods/2400/?tab=files), which removes all deprecated APIs. This may significantly improve performance, but mods which still show deprecation warnings won't work.
  * The SMAPI installer now also detects game folders in Steam's `.vdf` library data on Windows (thanks to pizzaoverhead!).
  * SMAPI now prevents mods from enabling Harmony debug mode, which impacts performance and creates a file on your desktop.  
    _You can allow debug mode by editing `smapi-internal/config.json` in your game folder._
  * Optimized performance and memory usage (thanks to atravita!).
  * Other internal optimizations.
  * Added more file extensions to ignore when searching for mod folders: `.7z`, `.tar`, `.tar.gz`, and `.xcf` (thanks to atravita!).
  * Removed transitional `UseRawImageLoading` option added in 3.15.0. This is now always enabled, except when PyTK is installed.
  * Fixed update alerts incorrectly shown for prerelease versions on GitHub that aren't marked as prerelease.

* For mod authors:
  * When [providing a mod API in a C# mod](https://stardewvalleywiki.com/Modding:Modder_Guide/APIs/Integrations), you can now get the mod requesting it as an optional parameter (thanks to KhloeLeclair!).
  * SMAPI now treats square brackets in the manifest `Name` field as round ones to avoid breaking tools which parse log files.
  * Made deprecation message wording stronger for the upcoming SMAPI 4.0.0 release.
  * The `Texture2D.Name` field is now set earlier to support mods like SpriteMaster.
  * Updated dependencies: [Harmony](https://harmony.pardeike.net) 2.2.2 (see [changes](https://github.com/pardeike/Harmony/releases/tag/v2.2.2.0)) and [FluentHttpClient](https://github.com/Pathoschild/FluentHttpClient#readme) 4.2.0 (see [changes](https://github.com/Pathoschild/FluentHttpClient/blob/develop/RELEASE-NOTES.md#420)).
  * Fixed `LocationListChanged` event not raised & memory leak occurring when a generated mine/volcano is removed (thanks to tylergibbs2!).

## 3.16.2
Released 31 August 2022 for Stardew Valley 1.5.6 or later.

* For players:
  * Fixed `NoSuitableGraphicsDeviceException` launch error for some players with compatible GPUs since 3.16.0.

## 3.16.1
Released 29 August 2022 for Stardew Valley 1.5.6 or later.

* For players:
  * Updated PyTK compatibility mode for the latest PyTK version.
  * Fixed broken mods sometimes incorrectly listed as duplicate.

## 3.16.0
Released 22 August 2022 for Stardew Valley 1.5.6 or later. See [release highlights](https://www.patreon.com/posts/70797008).

* For players:
  * Added error message if mod files are detected directly under `Mods` (instead of each mod having its own subfolder).
  * SMAPI now sets a success/error code when the game exits.  
    _This is used by your OS (like Windows) to decide whether to keep the console window open when the game ends._
  * Fixed SMAPI on Windows applying different DPI awareness settings than the game (thanks to spacechase0!).
  * Fixed Linux/macOS installer's color scheme question partly unreadable if the terminal background is dark.
  * Fixed error message when a mod loads an invalid PNG file (thanks to atravita!).
  * Fixed error message when a mod is duplicated, but one of the copies is also missing the DLL file. This now shows the duplicate-mod message instead of the missing-DLL message.
  * Fixed macOS launcher using Terminal regardless of the system's default terminal (thanks to ishan!).
  * Fixed best practices in Linux/macOS launcher scripts (thanks to ishan!).
  * Improved translations. Thanks to KediDili (updated Turkish)!

* For mod authors:
  * While loading your mod, SMAPI now searches for indirect dependencies in your mod's folder (thanks to TehPers)! This mainly enables F# mods.
  * **Raised deprecation message levels.**  
    _Deprecation warnings are now player-visible in the SMAPI console as faded `DEBUG` messages._
  * Updated to Pintail 2.2.1 (see [changes](https://github.com/Nanoray-pl/Pintail/blob/master/docs/release-notes.md#221)).
  * Switched SMAPI's `.pdb` files to the newer 'portable' format. This has no effect on mods.

* For the web UI:
  * Added log parser warning about performance of PyTK 1.23.0 or earlier.
  * Converted images to SVG (thanks to ishan!).
  * Updated log parser for the new update alert format in SMAPI 3.15.1.
  * Updated the JSON validator/schema for Content Patcher 1.28.0.
  * Fixed log parsing for invalid content packs.
  * Fixed log parsing if a mod logged a null character.

## 3.15.1
Released 06 July 2022 for Stardew Valley 1.5.6 or later.

* For players:
  * Added current version to update alerts (thanks to ishan!).
  * Fixed lag for some players since Stardew Valley 1.5.5.
  * Fixed `smapi-internal/config.user.json` overrides not applied after SMAPI 3.14.0.
  * Fixed PyTK not rescaling images correctly in some cases.  
    _When PyTK 1.23.0 or earlier is installed, this will disable the main performance improvements in SMAPI 3.15.0._
  * Updated compatibility list.

* For mod authors:
  * The [FluentHttpClient package](https://github.com/Pathoschild/FluentHttpClient#readme) is now loaded by SMAPI.
  * Fixed `TRACE` logs not tracking reloaded map tilesheets as a propagated asset.

* For the web UI:
  * Added log parser suggested fix for missing/outdated Error Handler, and improved visual styles.
  * Updated the JSON validator/schema for Content Patcher 1.27.0.
  * Fixed the mod count in the log parser metadata.

## 3.15.0
Released 17 June 2022 for Stardew Valley 1.5.6 or later. See [release highlights](https://www.patreon.com/posts/67877219).

* For players:
  * Optimized mod image file loading.
  * Minor optimizations (thanks to Michael Kuklinski / Ameisen!).
  * Updated compatibility list.

* For mod authors:
  * Added an [`IRawTextureData` asset type](https://stardewvalleywiki.com/Modding:Migrate_to_SMAPI_4.0#Raw_texture_data), to avoid creating full `Texture2D` instances in many cases.
  * In `smapi-internal/config.json`, you can now enable verbose logging for specific mods (instead of all or nothing).
  * Updated dependencies:
    * Harmony 2.2.1 (see changes in [2.2.0](https://github.com/pardeike/Harmony/releases/tag/v2.2.0.0) and [2.2.1](https://github.com/pardeike/Harmony/releases/tag/v2.2.1.0));
    * Newtonsoft.Json 13.0.1 (see [changes](https://github.com/JamesNK/Newtonsoft.Json/releases/tag/13.0.1));
    * Pintail 2.2.0 (see [changes](https://github.com/Nanoray-pl/Pintail/blob/master/docs/release-notes.md#220)).
  * Removed transitional `UsePintail` option added in 3.14.0 (now always enabled).
  * Fixed `onBehalfOf` arguments in the new content API being case-sensitive.
  * Fixed map edits which change warps sometimes rebuilding the NPC pathfinding cache unnecessarily, which could cause a noticeable delay for players.

## 3.14.7
Released 01 June 2022 for Stardew Valley 1.5.6 or later.

* For players:
  * Optimized reflection cache to reduce frame skips for some players.

* For mod authors:
  * Removed `runtimeconfig.json` setting which impacted hot reload support.

## 3.14.6
Released 27 May 2022 for Stardew Valley 1.5.6 or later.

* For players:
  * Fixed error in split-screen mode when a mod provides a localized asset in one screen but not another.
  * Minor optimizations.

## 3.14.5
Released 22 May 2022 for Stardew Valley 1.5.6 or later.

* For players:
  * Improved performance when mods change some asset types (including NPC portraits/sprites).
  * Fixed _could not find file_ error if a mod provides a localized version of a normally unlocalized asset and then stops providing it.
  * Fixed CurseForge update checks for the new CurseForge API.

## 3.14.4
Released 15 May 2022 for Stardew Valley 1.5.6 or later.

* For players:
  * Improved performance for mods using deprecated APIs.

* For mod authors:
  * Removed warning for mods which use `dynamic`.  
    _This no longer causes errors on Linux/macOS after Stardew Valley 1.5.5._

## 3.14.3
Released 12 May 2022 for Stardew Valley 1.5.6 or later.

* For players:
  * Reduced in-game performance impact.

* For mod authors:
  * Refactored how event handling works under the hood, particularly the new content API. This should have no effect on mod usage.
  * Verbose mode now logs the in-game time.
  * Fixed error when loading a `.xnb` file through the old content API without the file extension.
  * Fixed asset propagation for player sprites not fully updating recolor masks in some cases.

* For the web UI:
  * Updated the JSON validator/schema for Content Patcher 1.26.0.

## 3.14.2
Released 08 May 2022 for Stardew Valley 1.5.6 or later.

* For players:
  * Enabled case-insensitive file paths by default for Android and Linux players.  
    _This was temporarily disabled in SMAPI 3.14.1, and will remain disabled by default on macOS and Windows since their filesystems are already case-insensitive._
  * Various performance improvements.
* For mod authors:
  * Dynamic content packs created via `helper.ContentPacks.CreateTemporary` or `CreateFake` are now listed in the log file.
  * Fixed assets loaded through a fake content pack not working correctly since 3.14.0.

## 3.14.1
Released 06 May 2022 for Stardew Valley 1.5.6 or later.

* For players:
  * Improved performance for mods still using the previous content API.
  * Disabled case-insensitive file paths (introduced in 3.14.0) by default.  
    _You can enable them by editing `smapi-internal/config.json` if needed. They'll be re-enabled in an upcoming version after they're reworked a bit._
  * Removed experimental 'aggressive memory optimizations' option.  
    _This was disabled by default and is no longer needed in most cases. Memory usage will be better reduced by reworked asset propagation in the upcoming SMAPI 4.0.0._
  * Fixed 'content file was not found' error when the game tries to load unlocalized text from a localizable mod data asset in 3.14.0.
  * Fixed error reading empty JSON files. These are now treated as if they didn't exist (matching pre-3.14.0 behavior).
  * Updated compatibility list.

## 3.14.0
Released 01 May 2022 for Stardew Valley 1.5.6 or later. See [release highlights](https://www.patreon.com/posts/65265507).

### For players
This is a big update, but existing mods should all work fine. If the latest version of a mod breaks in SMAPI 3.14, please report it [on the SMAPI mod page](https://www.nexusmods.com/stardewvalley/mods/2400?tab=posts).

* Improvements:
  * SMAPI now ignores dot-prefixed files when searching for mod folders (thanks to Nuztalgia!).
  * On Linux, SMAPI now fixes many case-sensitive mod path issues automatically.
  * On Linux/macOS, added `--use-current-shell` [command-line argument](technical/smapi.md#command-line-arguments) to avoid opening a separate terminal window.
  * Improved performance in some cases.
  * Improved translations. Thanks to ChulkyBow (updated Ukrainian)!
  * Dropped update checks for the unofficial 64-bit patcher (obsolete since SMAPI 3.12.6).
* Fixes:
  * Fixed some movie theater textures not translated when loaded through SMAPI (specifically assets with the `_international` suffix).
  * Fixed the warning text when a mod causes an asset load conflict with itself.
  * Fixed `--no-terminal` [command-line argument](technical/smapi.md#command-line-arguments) on Linux/macOS still opening a terminal window, even if nothing is logged to it (thanks to Ryhon0!).
  * Fixed `player_add` console command not handling journal scraps and secret notes correctly.
  * Fixed `set_farm_type` console command not updating warps.
* For the web UI:
  * Improved log parser UI (thanks to KhloeLeclair!):
    * Added pagination for big logs.
    * Added search box to filter the log.
    * Added option to show/hide content packs in the mod list.
    * Added jump links in the sidebar.
    * The filter options now stick to the top of the screen when scrolling.
    * Rewrote rendering to improve performance.

### For mod authors
This is a big release that includes the new features planned for SMAPI 4.0.0.

For C# mod authors: your mods should still work fine in SMAPI 3.14.0. However you should review the [migration to SMAPI 4.0](https://stardewvalleywiki.com/Modding:Migrate_to_SMAPI_4.0) guide and update your mods when possible. Deprecated code will be removed when SMAPI 4.0.0 releases later this year (no sooner than August 2022), and break any mods which haven't updated by that time. You can update affected mods now, there's no need to wait for 4.0.0.

For content pack authors: SMAPI 3.14.0 and 4.0.0 don't affect content packs. They should work fine as long as
the C# mod that loads them is updated.

* Major changes:
  * Added [content events](https://stardewvalleywiki.com/Modding:Modder_Guide/APIs/Events#Content), which will replace `IAssetEditor` and `IAssetLoader` in SMAPI 4.0.0.  
    _These include new features not supported by the old API like load conflict resolution, edit priority, and content pack labels. They also support new cases like easily detecting when an asset has changed, and avoid data corruption issues in some edge cases._
  * Added [nullable reference type annotations](https://stardewvalleywiki.com/Modding:Migrate_to_SMAPI_4.0#Nullable_reference_type_annotations) for all APIs.
  * Added [`helper.GameContent` and `helper.ModContent`](https://stardewvalleywiki.com/Modding:Migrate_to_SMAPI_4.0#Content_loading_API), which will replace `helper.Content` in SMAPI 4.0.0.
  * Improved [mod-provided API](https://stardewvalleywiki.com/Modding:Modder_Guide/APIs/Integrations#Mod-provided_APIs) proxying (thanks to Shockah!).  
    _This adds support for custom interfaces in return values or input arguments, custom enums if their values match, generic methods, and more. This is an internal change, you don't need to do anything different in your mod code._
  * Mod files loaded through SMAPI APIs (including `helper.Content.Load`) are now case-insensitive, even on Linux.
  * Enabled deprecation notices for all deprecated APIs. These will only be shown in `TRACE` logs for at least a month after SMAPI 3.14.0 releases.
* Other improvements:
  * Added `IAssetDataForImage.ExtendMap` to resize maps in asset editors.
  * Added `IContentPack.ModContent` property to manage content pack assets.
  * Added `Constants.ContentPath` to get the full path to the game's `Content` folder.
  * Added `IAssetName` fields to the info received by `IAssetEditor`, `IAssetLoader`, and content event methods.  
    _This adds methods for working with asset names, parsed locales, etc._
  * Added `helper.Content.ParseAssetName` to get an `IAssetName` for an arbitrary asset key.
  * Added [command-line arguments](technical/smapi.md#command-line-arguments) to toggle developer mode (thanks to Tondorian!).
  * If an asset is loaded multiple times in the same tick, `IAssetLoader.CanLoad` and `IAssetEditor.CanEdit` are now cached unless invalidated by `helper.Content.InvalidateCache`.
  * The `ISemanticVersion` comparison methods (`CompareTo`, `IsBetween`, `IsNewerThan`, and `IsOlderThan`) now allow null values. A null version is always considered older than any non-null version per [best practices](https://docs.microsoft.com/en-us/dotnet/api/system.icomparable-1.compareto#remarks).
  * Deprecation notices now show a shorter stack trace in most cases, so it's clearer where the deprecated code is in the mod.
* Fixes:
  * Fixed the `SDate` constructor being case-sensitive.
  * Fixed support for using locale codes from custom languages in asset names (e.g. `Data/Achievements.eo-EU`).
  * Fixed issue where suppressing `[Left|Right]Thumbstick[Down|Left]` keys would suppress the opposite direction instead.
  * Fixed null handling in various edge cases.
* For the web UI:
  * Updated the JSON validator/schema for Content Patcher 1.25.0.
  * Added `data-*` attributes to the log parser page for external tools.
  * Fixed JSON validator showing incorrect error for update keys without a subkey.

### For SMAPI contributors
* You no longer need a Nexus API key to launch the `SMAPI.Web` project locally.

## 3.13.4
Released 16 January 2022 for Stardew Valley 1.5.6 or later.

* For players:
  * Fixed Linux/macOS launch error in 3.13.3.

## 3.13.3
Released 16 January 2022 for Stardew Valley 1.5.6 or later.

* For players:
  * **SMAPI now needs Stardew Valley 1.5.6 or later.**
  * Added automatic fix for custom maps which are missing a required tilesheet.
  * Added automatic save recovery when a custom farm type isn't available anymore.
  * Added the game's new build number to the SMAPI console + log.
  * The installer now detects Xbox app game folders.
  * Reduced mod loading time a bit.
  * Fixed macOS launch issue when using some terminals (thanks to bruce2409!).
  * Fixed Linux/macOS terminal ignoring backspaces in Stardew Valley 1.5.5+.
  * Fixed extra newlines in the SMAPI console.
  * Fixed outdated instructions in Steam error message.
  * Fixed uninstaller not removing `StardewModdingAPI.deps.json` file.
  * Simplified [running without a terminal on Linux/macOS](https://stardewvalleywiki.com/Modding:Player_Guide/Troubleshooting#SMAPI_doesn.27t_recognize_controller_.28Steam_only.29) when needed.
  * Updated compatibility list.
  * Improved translations. Thanks to ChulkyBow (added Ukrainian)!

* For the web UI:
  * Added log instructions for Xbox app on Windows.
  * Added log download option.
  * Redesigned log instruction UI.
  * Fixed log parser not correctly handling multiple mods having the exact same name.
  * Fixed JSON validator not recognizing manifest [update subkeys](https://stardewvalleywiki.com/Modding:Modder_Guide/APIs/Update_checks#Update_subkeys).

## 3.13.2
Released 05 December 2021 for Stardew Valley 1.5.5 or later.

* For players:
  * You no longer need .NET 5 to install or use SMAPI.
  * The installer now detects when the game folder contains an incompatible legacy game version.
  * Updated for the latest Stardew Valley 1.5.5 hotfix.
  * Updated compatibility list.

* For the web UI:
  * Fixed the JSON validator marking `.fnt` files invalid in Content Patcher files.

* For SMAPI maintainers:
  * Added [release package scripts](technical/smapi.md) to streamline preparing SMAPI releases.

## 3.13.1
Released 30 November 2021 for Stardew Valley 1.5.5 or later.

* For players:
  * Improved .NET 5 validation in Windows installer to better explain how to get the right version.
  * Fixed installer failing on Windows when run from the game folder.

## 3.13.0
Released 30 November 2021 for Stardew Valley 1.5.5 or later. See [release highlights](https://www.patreon.com/posts/59348226).

* For players:
  * Updated for Stardew Valley 1.5.5.
  * Added `set_farm_type` [console command](https://stardewvalleywiki.com/Modding:Console_commands#Console_commands) to change the current farm type.
  * Fixed installer window closing immediately if the installer crashed.
  * Updated compatibility list.

* For mod authors:
  * Migrated to 64-bit MonoGame and .NET 5 on all platforms (see [migration guide for mod authors](https://stardewvalleywiki.com/Modding:Migrate_to_Stardew_Valley_1.5.5)).
  * Added support for [map overlays via `asset.AsMap().PatchMap`](https://stardewvalleywiki.com/Modding:Modder_Guide/APIs/Content#Edit_a_map).
  * Added support for loading BmFont `.fnt` files for [custom languages](https://stardewvalleywiki.com/Modding:Custom_languages) through the [content API](https://stardewvalleywiki.com/Modding:Modder_Guide/APIs/Content).

* For the web UI:
  * Updated the JSON validator/schema for Content Patcher 1.24.0.

**Update note for players with older systems:**  
The game now has two branches: the _main branch_ which you'll get by default, and an optional
[_compatibility branch_ for older systems](https://www.stardewvalley.net/compatibility/). The two
branches have identical content, but use [different technologies](https://stardewvalleywiki.com/Modding:Migrate_to_Stardew_Valley_1.5.5#Game_compatibility_branch).

Unfortunately **SMAPI only supports the main branch of the game**. There are formidable difficulties
across all mods in supporting all three variations, 32-bit imposes significant restrictions on what
mods can do, and the [Steam hardware stats](https://store.steampowered.com/hwsurvey) show that 99.69%
of players now have 64-bit.

## 3.12.8
Released 18 October 2021 for Stardew Valley 1.5.4.

* For players:
  * Fixed mod edits to the farmhouse shifting the player down one tile in some cases.
  * Fixed map tile rotations/flips not working for farmhands in split-screen mode.
  * Improved translations. Thanks to ellipszist (added Thai) and Zangorr (added Polish)!  
    _These are custom languages which require Stardew Valley 1.5.5 and the [Polish](https://www.nexusmods.com/stardewvalley/mods/3616) or [Thai](https://www.nexusmods.com/stardewvalley/mods/7052) mod._

* For mod authors:
  * SMAPI now intercepts dictionary duplicate-key errors and adds the key to the error message to simplify troubleshooting. (Due to Harmony limitations, this only works for the dictionary types used by the game.)
  * Fixed barn/coop exit warps being reset when you edit their interior map.

* For the web UI:
  * Added support for unified [mod data overrides](https://stardewvalleywiki.com/Modding:Mod_compatibility#Mod_data_overrides) defined on the wiki.
  * The mod compatibility list now shows separate beta stats when 'show advanced info' is enabled.

## 3.12.7
Released 18 September 2021 for Stardew Valley 1.5.4.

* For players:
  * Added more progress updates in the log during startup.
  * Simplified asset load error message.
  * Simplified exception logs.
  * Fixed crash loading mods with corrupted translation files.

* For mod authors:
  * Added asset propagation for `LooseSprites\Giftbox`.
  * Improved SMAPI's crossplatform read/writing of `Color`, `Point`, `Rectangle`, and `Vector2` in JSON to support nullable fields too.

* For the web UI:
  * The mod compatibility list now shows the beta status by default (if any).
  * Fixed JSON validator line numbers sometimes incorrect.

## 3.12.6
Released 03 September 2021 for Stardew Valley 1.5.4.

* For players:
  * Added friendly error when using SMAPI 3.2._x_ with Stardew Valley 1.5.5 or later.
  * Improved mod compatibility in 64-bit mode (thanks to spacechase0!).
  * Reduced load time when scanning/rewriting many mods for compatibility.
  * **Dropped support for unofficial 64-bit mode**. You can now use the [official 64-bit Stardew Valley 1.5.5 beta](https://stardewvalleywiki.com/Modding:Migrate_to_64-bit_on_Windows) instead.
  * Updated compatibility list.

* For mod authors:
  * Added `PathUtilities.NormalizeAssetName` and `PathUtilities.PreferredAssetSeparator` to prepare for the upcoming Stardew Valley 1.5.5.
  * **SMAPI no longer propagates changes to `Data/Bundles`.**  
    _You can still load/edit the asset like usual, but if bundles have already been loaded for a save, SMAPI will no longer dynamically update the in-game bundles to reflect the changes. Unfortunately this caused bundle corruption when playing in non-English._
  * Fixed content packs created via `helper.ContentPacks.CreateFake` or `CreateTemporary` not initializing translations correctly.

* For console commands:
  * Added `hurry_all` command which immediately warps all NPCs to their scheduled positions.

**Update note for mod authors:**  
Stardew Valley 1.5.5 will change how asset names are formatted. If you use `PathUtilities.NormalizePath`
to format asset names, you should switch to `PathUtilities.NormalizeAssetName` now so your code will
continue working in the next game update.

## 3.12.5
Released 26 August 2021 for Stardew Valley 1.5.4.

* Fixed some mods in unofficial 64-bit mode no longer loading after SMAPI 3.12.3.

## 3.12.4
Released 25 August 2021 for Stardew Valley 1.5.4.

* For players:
  * Fixed error loading some mods in SMAPI 3.12.3.

## 3.12.3
Released 25 August 2021 for Stardew Valley 1.5.4.

* For players:
  * Added friendly error in 64-bit mode when a mod is 32-bit only.
  * Fixed console encoding issues on Linux/macOS.
  * Fixed some installer errors not showing info header.

* For mod authors:
  * Added `helper.Translation.GetInAllLocales` to get a translation in every available locale.
  * Fixed Visual Studio debugger crash when any mods are rewritten for compatibility (thanks to spacechase0!).
  * Fixed `helper.Data.WriteJsonFile` not deleting the file if the model is null, unlike the other `Write*` methods.
  * Fixed error-handling for `StackOverflowException` thrown on Linux/macOS.
  * Internal changes to prepare for Stardew Valley 1.5.5.

* For the web API:
  * Fixed update checks not shown for prerelease mod versions when you have a SMAPI beta.
  * Fixed update checks shown for prerelease mod versions if you have a working non-prerelease version.

## 3.12.2
Released 05 August 2021 for Stardew Valley 1.5.4.

* For players:
  * Fixed error creating a new save or joining a multiplayer world in 3.12.1.

* For mod authors:
  * Reverted the `Constants.Save*` fix in SMAPI 3.12.1.  
    _The change caused a number of other issues, and is only needed for rare cases where the save folder was invalid. This may be revisited in a future version instead._
  * Fixed `NullReferenceException` in SMAPI's error-handling when trying to handle an invalid `ReflectionTypeLoadException`.

## 3.12.1
Released 03 August 2021 for Stardew Valley 1.5.4.

* For players:
  * The software conflict message is now shown as a warning to simplify troubleshooting.
  * Fixed error loading older Harmony mods for some Windows players using unofficial 64-bit Stardew Valley.
  * Updated compatibility list.

* For mod authors:
  * Fixed `Constants.Save*` fields incorrect if the save's folder name and ID don't match.

## 3.12.0
Released 01 August 2021 for Stardew Valley 1.5.4. See [release highlights](https://www.patreon.com/posts/54388616).

* For players:
  * Added save recovery when content mods leave null objects in the save (in _Error Handler_).
  * Added error if the wrong SMAPI bitness is installed (e.g. 32-bit SMAPI with 64-bit game).
  * Added error if some SMAPI files aren't updated correctly.
  * Added `removable` option to the `world_clear` console command (in _Console Commands_, thanks to bladeoflight16!).
  * Fixed handling of Unicode characters in console commands.
  * Fixed intermittent error if a mod gets mod-provided APIs asynchronously.
  * Fixed crash when creating a farm name containing characters that aren't allowed in a folder path.

* For mod authors:
  * **Updated Harmony 1.2.0.1 to 2.1.0 (see [_migrate to Harmony 2.0_](https://stardewvalleywiki.com/Modding:Migrate_to_Harmony_2.0) for more info).**
  * SMAPI now intercepts `KeyNotFoundException` errors and adds the key to the error message to simplify troubleshooting. (Due to Harmony limitations, this only works for the dictionary types used by the game.)
  * Fixed error loading `.xnb` files from the local mod folder.
  * Fixed reloading a map not correctly reapplying interior doors.

## 3.11.0
Released 09 July 2021 for Stardew Valley 1.5.4. See [release highlights](https://www.patreon.com/posts/53514295).

* For players:
  * Updated for Stardew Valley 1.4.5 multiplayer hotfix on Linux/macOS.
  * Fixed installer error on Windows when running as administrator (thanks to LostLogic!).
  * Fixed installer error on some Windows systems (thanks to eddyballs!).
  * Fixed error if SMAPI fails to dispose on game exit.
  * Fixed `player_add` and `list_items` console commands not including some shirts _(in Console Commands)_.

* For mod authors:
  * Added `World.FurnitureListChanged` event (thanks to DiscipleOfEris!).
  * Added asset propagation for building/house paint masks.
  * Added log message for troubleshooting if Windows software which often causes issues is installed (currently MSI Afterburner and RivaTuner).
  * Improved validation for the manifest `Dependencies` field.
  * Fixed validation for mods with invalid version `0.0.0`.
  * Fixed _loaded with custom settings_ trace log added when using default settings.
  * Fixed `Constants.SaveFolderName` and `Constants.CurrentSavePath` not set correctly in rare cases.

* For the web UI and JSON validator:
  * Updated the JSON validator/schema for Content Patcher 1.23.0.
  * Fixed [JSON schema](technical/web.md#using-a-schema-file-directly) in Visual Studio Code warning about comments and trailing commas.
  * Fixed JSON schema for `i18n` files requiring the wrong value for the `$schema` field.

## 3.10.1
Released 03 May 2021 for Stardew Valley 1.5.4.

* For players:
  * Fixed installer leaving an unneeded `StardewModdingAPI-x64.exe` file in 32-bit game folders.

## 3.10.0
Released 03 May 2021 for Stardew Valley 1.5.4. See [release highlights](https://www.patreon.com/posts/50764911).

* For players:
  * Added full support for the [unofficial 64-bit Stardew Valley patch](https://stardewvalleywiki.com/Modding:Migrate_to_64-bit_on_Windows), which removes memory limits. The installer detects which version of SMAPI you need, and SMAPI shows update alerts for Stardew64Installer if applicable.
  * Added smarter grouping for skipped mods, so it's easier to see root dependencies to update first.
  * Added crash recovery when the game can't update a map's seasonal tilesheets _(in Error Handler)_. SMAPI will log an error and keep the previous tilesheets in that case.
  * Added installer option to enter a custom game path even if it detected a game folder.
  * `*.ico` files are now ignored when scanning for mods.
  * Fixed error for non-English players after returning to title, reloading, and entering town with a completed movie theater.
  * Fixed `world_clear` console command not removing resource clumps outside the farm and secret woods.
  * Fixed error running SMAPI in a strict sandbox on Linux (thanks to kuesji!).
  * Fixed `StardewModdingAPI.bin.osx` on macOS overwritten with an identical file on launch which would reset file permissions (thanks to 007wayne!).
  * Fixed inconsistent spelling/style for 'macOS'.

* For modders:
  * Added support for [ignoring local map tilesheet files when loading a map](https://stardewvalleywiki.com/Modding:Maps#Local_copy_of_a_vanilla_tilesheet).
  * Added asset propagation for `Data\Concessions`.
  * Added SMAPI version and bitness to the console title before startup to simplify troubleshooting.
  * If a map loads a tilesheet path with no file extension, SMAPI now automatically links it to a `.png` version in the map folder if possible.
  * Improved error-handling during asset propagation.
  * Fixed `Context.IsMainPlayer` returning true for a farmhand in split-screen mode before the screen is initialized.
  * Fixed error when editing bundle data while a split-screen player is joining.
  * Fixed update subkeys not working in file descriptions for Nexus mods marked as adult content.

## 3.9.5
Released 21 March 2021 for Stardew Valley 1.5.4.

* For players:
  * Added console command to reset community center bundles _(in Console Commands)_.
  * Disabled aggressive memory optimization by default.  
    _The option was added in SMAPI 3.9.2 to reduce errors for some players, but it can cause multiplayer crashes with some mods. If you often see `OutOfMemoryException` errors, you can edit `smapi-internal/config.json` to re-enable it. We're experimenting with making Stardew Valley 64-bit to address memory issues more systematically._
  * Fixed bundles corrupted in non-English saves created after SMAPI 3.9.2.  
    _If you have an affected save, you can load your save and then enter the `regenerate_bundles confirm` command in the SMAPI console to fix it._
  * Internal changes to prepare for unofficial 64-bit.

* For mod authors:
  * Improved asset propagation:
    * Added for interior door sprites.
    * SMAPI now updates the NPC pathfinding cache when map warps are changed through the content API.
    * Reduced performance impact of invalidating cached assets before a save is loaded.
    * Fixed asset changes not reapplied in the edge case where you're playing in non-English, and the changes are only applied after the save is loaded, and the player returns to title and reloads a save, and the game reloads the target asset before the save is loaded.
  * Added a second `KeybindList` constructor to simplify single-key default bindings.
  * Added a `Constants.GameFramework` field which indicates whether the game is using XNA Framework or MonoGame.  
    _Note: mods don't need to handle the difference in most cases, but some players may use MonoGame on Windows in upcoming versions. Mods which check `Constants.TargetPlatform` should review usages as needed._

## 3.9.4
Released 07 March 2021 for Stardew Valley 1.5.4.

* For players:
  * Fixed installer error if the `Mods` folder doesn't exist in 3.9.3.

## 3.9.3
Released 07 March 2021 for Stardew Valley 1.5.4.

* For players:
  * Added descriptive error if possible when a `PathTooLongException` crashes SMAPI or the installer.
  * The installer window now tries to stay open if it crashed, so you can read the error and ask for help.
  * Fixed console showing _found 1 mod with warnings_ with no mods listed in some cases.

* For mod authors:
  * Added three stages to the specialised [`LoadStageChanged` event](https://stardewvalleywiki.com/Modding:Modder_Guide/APIs/Events#Specialised): `CreatedInitialLocations`, `SaveAddedLocations`, and `ReturningToTitle`.
  * Fixed `RewriteMods` option ignored when rewriting for OS compatibility.
  * Fixed edge case when playing as a farmhand in non-English where translatable assets loaded via `IAssetLoader` weren't reapplied immediately when the server disconnects.

* For the web UI:
  * Updated the JSON validator/schema for Content Patcher 1.21.

## 3.9.2
Released 21 February 2021 for Stardew Valley 1.5.4.

* For players:
  * Added more aggressive memory optimization to reduce `OutOfMemoryException` errors with some mods.
  * Improved error when `Stardew Valley.exe` exists but can't be loaded.
  * Fixed error running `install on Windows.bat` in very rare cases.
  * Fixed `world_settime` command not always updating outdoor ambient lighting _(in Console Commands)_.

* For mod authors:
  * Added early detection of disposed textures so the error details are more relevant _(in Error Handler)_.
  * Added error details when an event command fails _(in Error Handler)_.
  * Fixed asset propagation for `TileSheets/ChairTiles` not changing existing map seats.
  * Fixed edge case when playing in non-English where translatable assets loaded via `IAssetLoader` would no longer be applied after returning to the title screen unless manually invalidated from the cache.

* For the web UI:
  * Updated compatibility list for the new wiki.
  * Updated the JSON validator/schema for Content Patcher 1.20.
  * Fixed mod compatibility list error if a mod has no name.

* For SMAPI developers:
  * Fixed SMAPI toolkit defaulting the mod type incorrectly if a mod's `manifest.json` has neither `EntryDll` nor `ContentPackFor`. This only affects external tools, since SMAPI itself validates those fields separately.

## 3.9.1
Released 25 January 2021 for Stardew Valley 1.5.4.

* For players:
  * Fixed _tile contains an invalid TileSheet reference_ crash after mods change certain maps.
  * Fixed _patched game code_ issue shown for the bundled Error Handler mod.

## 3.9.0
Released 22 January 2021 for Stardew Valley 1.5.4. See [release highlights](https://www.patreon.com/posts/46553874).

* For players:
  * Updated for Stardew Valley 1.5.4.
  * Improved game detection in the installer:
    * The installer now prefers paths registered by Steam or GOG Galaxy.
    * The installer now detects default manual GOG installs.
  * Added clearer error text for empty mod folders created by Vortex.
  * Fixed the game's map changes not always reapplied correctly after mods change certain maps, which caused issues like the community center resetting to its non-repaired texture.
  * Fixed compatibility for very old content packs which still load maps from `.xnb` files. These were broken by map loading changes in Stardew Valley 1.5, but SMAPI now corrects them automatically.
  * Fixed some broken mods incorrectly listed as XNB mods under 'skipped mods'.

* For mod authors:
  * Added new input APIs:
    * Added an [API for multi-key bindings](https://stardewvalleywiki.com/Modding:Modder_Guide/APIs/Input#KeybindList).
    * Added a new [`Input.ButtonsChanged` event](https://stardewvalleywiki.com/Modding:Modder_Guide/APIs/Events#Input.ButtonsChanged).
    * Added a `buttonState.IsDown()` extension.
    * Added a `helper.Input.SuppressActiveKeybinds` method to suppress the active buttons in a keybind list.
  * Improved multiplayer APIs:
    * `PerScreen<T>` now lets you get/set the value for any screen, get all active values, or clear all values.
    * Peer data from the multiplayer API/events now includes `IsSplitScreen` and `ScreenID` fields.
    * Fixed network messages through the multiplayer API being sent to players who don't have SMAPI installed in some cases.
  * Improved asset propagation:
    * Updated map propagation for the changes in Stardew Valley 1.5.4.
    * Added propagation for some `Strings\StringsFromCSFiles` keys (mainly short day names).
    * Fixed quarry bridge not fixed if the mountain map was reloaded.
  * Added an option to disable rewriting mods for compatibility (thanks to Bpendragon!). This prevents older mods from loading, but bypasses a Visual Studio crash when debugging.
  * Game errors shown in the chatbox are now logged.
  * Moved vanilla error-handling into a new Error Handler mod. This simplifies the core SMAPI logic, and lets users disable it if needed.

* For the Console Commands mod:
  * Removed the `inf` option for `player_sethealth`, `player_setmoney`, and `player_setstamina`. You can use mods like [CJB Cheats Menu](https://www.nexusmods.com/stardewvalley/mods/4) instead for that.

* For the Error Handler mod:
  * Added a detailed message for the _Input string was not in a correct format_ error when the game fails to parse an item text description.

* For the web UI:
  * Fixed JSON validator incorrectly marking some manifest update keys as invalid.

## 3.8.4
Released 15 January 2021 for Stardew Valley 1.5.3 or later.

* For players:
  * Updated for Stardew Valley 1.5.3.
  * Fixed issue where title screen music didn't stop after loading a save.

* For mod authors:
  * Fixed `SemanticVersion` comparisons returning wrong value in rare cases.

## 3.8.3
Released 08 January 2021 for Stardew Valley 1.5.2 or later.

* For players:
  * Updated for Stardew Valley 1.5.2.
  * Reduced memory usage.
  * You can now enter console commands for a specific screen in split-screen mode by adding `screen=ID` to the command.
  * Typing `help` in the SMAPI console is now more helpful.

* For mod authors:
  * Simplified tilesheet order warning added in SMAPI 3.8.2.

* For the Console Commands mod:
  * Removed experimental `performance` command. Unfortunately this impacted SMAPI's memory usage and performance, and the data was often misinterpreted. This may be replaced with more automatic performance alerts in a future version.

## 3.8.2
Released 03 January 2021 for Stardew Valley 1.5.1 or later.

* For players:
  * SMAPI now blocks farm map replacements that would crash the game in Stardew Valley 1.5.
  * On Linux, the SMAPI installer now auto-detects Flatpak Steam paths.
  * Updated compatibility list.
  * Fixed errors when multiple players join in split-screen mode.
  * Fixed 'skipped mods' section repeating mods in some cases.
  * Fixed out-of-date error text.

* For mod authors:
  * Added warning when a map replacement changes the order/IDs of the original tilesheets, which may cause errors and crashes. Doing so for a farm map is blocked outright since that causes a consistent crash in Stardew Valley 1.5.
  * Message data from the `ModMessageReceived` event now uses the same serializer settings as the rest of SMAPI. That mainly adds support for sending crossplatform `Color`, `Point`, `Vector2`, `Rectangle`, and `SemanticVersion` fields through network messages.
  * When a mod is blocked by SMAPI's compatibility override list, the `TRACE` messages while loading it now say so and indicate why.
  * Fixed how the input API handles UI scaling. This mainly affects `ICursorPosition` values returned by the API; see [the wiki docs](https://stardewvalleywiki.com/Modding:Modder_Guide/APIs/Input#ICursorPosition) for how to account for UI scaling.

## 3.8.1
Released 26 December 2020 for Stardew Valley 1.5.1 or later.

* For players:
  * Fixed broken community center bundles for non-English saves created in Stardew Valley 1.5. Affected saves will be fixed automatically on load.

* For mod authors:
  * World events are now raised for volcano dungeon levels.
  * Added `apply_save_fix` command to reapply a save migration in exceptional cases. This should be used very carefully. Type `help apply_save_fix` for details.
  * **Deprecation notice:** the `Helper.ConsoleCommands.Trigger` method is now deprecated and should no longer be used. See [integration APIs](https://stardewvalleywiki.com/Modding:Modder_Guide/APIs/Integrations) for better mod integration options. It will eventually be removed in SMAPI 4.0.

For the web UI:
  * Fixed edge cases in SMAPI log parsing.

## 3.8.0
Released 21 December 2020 for Stardew Valley 1.5 or later. See [release highlights](https://www.patreon.com/posts/45294737).

* For players:
  * Updated for Stardew Valley 1.5, including split-screen support.
  * You can now run the installer from a subfolder of your game folder to auto-detect it. That simplifies installation if you have multiple copies of the game or it can't otherwise auto-detect the game path.
  * Clarified error when the SMAPI installer is in the `Mods` folder.

* For mod authors:
  * Added `PerScreen<T>` utility and new `Context` fields to simplify split-screen support in mods.
  * Added screen ID to log when playing in split-screen mode.

* For the Console Commands mod:
  * Added `furniture` option to `world_clear`.

* For the web UI:
  * Updated the JSON validator/schema for Content Patcher 1.19.

## 3.7.6
Released 21 November 2020 for Stardew Valley 1.4.1 or later.

* For players:
  * Fixed error when heuristically rewriting an outdated mod in rare cases.
  * Fixed rare 'collection was modified' error when using `harmony summary` console command.

* For mod authors:
  * Updated TMXTile to 1.5.8 to fix exported `.tmx` files losing tile index properties.

* For the Console Commands mod:
  * `player_add` can now spawn shirts normally only available during character customization.
  * `player_add` now applies fish pond rules for roe items. (That mainly adds Clam Roe, Sea Urchin Roe, and custom roe from mods.)

## 3.7.5
Released 16 October 2020 for Stardew Valley 1.4.1 or later.

* For mod authors:
  * Fixed changes to the town map asset not reapplying the game's community center, JojaMart, and Pam house changes.

## 3.7.4
Released 03 October 2020 for Stardew Valley 1.4.1 or later.

* For players:
  * Improved performance on some older computers (thanks to millerscout!).
  * Fixed update alerts for Chucklefish forum mods broken by a recent site change.

* For mod authors:
  * Updated dependencies (including Mono.Cecil 0.11.2 → 0.11.3 and Platonymous.TMXTile 1.3.8 → 1.5.6).
  * Fixed asset propagation for `Data\MoviesReactions`.
  * Fixed error in content pack path handling when you pass a null path.

* For the web UI:
  * Updated the JSON validator/schema for Content Patcher 1.18.

* For SMAPI developers:
  * Simplified preparing a mod build config package release.

## 3.7.3
Released 16 September 2020 for Stardew Valley 1.4.1 or later.

* For players:
  * Fixed errors on Linux/macOS due to content packs with incorrect filename case.
  * Fixed map rendering crash due to conflict between SMAPI and PyTK.
  * Fixed error in heuristically-rewritten mods in rare cases (thanks to collaboration with ZaneYork!).

* For mod authors:
  * File paths accessed through `IContentPack` are now case-insensitive (even on Linux).

* For the web UI:
  * You can now renew the expiry for an uploaded JSON/log file if you need it longer.

## 3.7.2
Released 08 September 2020 for Stardew Valley 1.4.1 or later.

* For players:
  * Fixed mod recipe changes not always applied in 3.7.

* For mod authors:
  * Renamed `PathUtilities.NormalizePathSeparators` to `NormalizePath`, and added normalization for more cases.

## 3.7.1
Released 08 September 2020 for Stardew Valley 1.4.1 or later.

* For players:
  * Fixed input-handling bugs in 3.7.

## 3.7.0
Released 07 September 2020 for Stardew Valley 1.4.1 or later. See [release highlights](https://www.patreon.com/posts/41341767).

* For players:
  * Added heuristic compatibility rewrites. (This improves mod compatibility with Android and future game updates.)
  * Tweaked the rules for showing update alerts (see _for SMAPI developers_ below for details).
  * Simplified the error shown for duplicate mods.
  * Fixed crossplatform compatibility for mods which use the `[HarmonyPatch(type)]` attribute (thanks to spacechase0!).
  * Fixed map tile rotation broken when you return to the title screen and reload a save.
  * Fixed broken URL in update alerts for unofficial versions.
  * Fixed rare error when a mod adds/removes event handlers asynchronously.
  * Fixed rare issue where the console showed incorrect colors when mods wrote to it asynchronously.
  * Fixed SMAPI not always detecting broken field references in mod code.
  * Removed the experimental `RewriteInParallel` option added in SMAPI 3.6 (it was already disabled by default). Unfortunately this caused intermittent and unpredictable errors when enabled.
  * Internal changes to prepare for upcoming game updates.

* For mod authors:
  * Added `PathUtilities` to simplify working with file/asset names.
  * You can now read/write `SDate` values to JSON (e.g. for `config.json`, network mod messages, etc).
  * Fixed asset propagation not updating title menu buttons immediately on Linux/macOS.

* For the web UI:
  * Updated the JSON validator/schema for Content Patcher 1.16 and 1.17.

* For SMAPI developers:
  * The web API now returns an update alert in two new cases: any newer unofficial update (previously only shown if the mod was incompatible), and a newer prerelease version if the installed non-prerelease version is broken (previously only shown if the installed version was prerelease).
  * Reorganised the SMAPI core to reduce coupling to game types like `Game1`, make it easier to navigate, and simplify future game updates.
  * SMAPI now automatically fixes code broken by these changes in game code, so manual rewriters are no longer needed:
    * reference to a method with new optional parameters;
    * reference to a field replaced by a property;
    * reference to a field replaced by a `const` field.
  * `FieldReplaceRewriter` now supports mapping to a different target type.

## 3.6.2
Released 02 August 2020 for Stardew Valley 1.4.1 or later.

* For players:
  * Improved compatibility with some Linux terminals (thanks to jlaw and Spatterjaaay!).
  * Fixed rare error when a mod adds/removes an event handler from an event handler.
  * Fixed string sorting/comparison for some special characters.

* For the Console Commands mod:
  * Fixed error opening menu when some item data is invalid.
  * Fixed spawned Floor TV not functional as a TV (thanks to Platonymous!).
  * Fixed spawned sturgeon roe having incorrect color.

* For mod authors:
  * Updated internal dependencies.
  * SMAPI now ignores more file types when scanning for mod folders (`.doc`, `.docx`, `.rar`, and `.zip`).
  * Added current GPU to trace logs to simplify troubleshooting.

## 3.6.1
Released 21 June 2020 for Stardew Valley 1.4.1 or later.

* Fixed event priority sorting.

## 3.6.0
Released 20 June 2020 for Stardew Valley 1.4.1 or later. See [release highlights](https://www.patreon.com/posts/38441800).

* For players:
  * Added crossplatform compatibility for mods which use the `[HarmonyPatch(type)]` attribute.
  * Added experimental option to reduce startup time when loading mod DLLs (thanks to ZaneYork!). Enable `RewriteInParallel` in the `smapi-internal/config.json` to try it.
  * Reduced processing time when a mod loads many unpacked images (thanks to Entoarox!).
  * Mod load warnings are now listed alphabetically.
  * macOS files starting with `._` are now ignored and can no longer cause skipped mods.
  * Simplified paranoid warning logs and reduced their log level.
  * Fixed black maps on Android for mods which use `.tmx` files.
  * Fixed `BadImageFormatException` error detection.
  * Fixed `reload_i18n` command not reloading content pack translations.

* For the web UI:
  * Added GitHub licenses to mod compatibility list.
  * Improved JSON validator:
    * added SMAPI `i18n` schema;
    * editing an uploaded file now remembers the selected schema;
    * changed default schema to plain JSON.
  * Updated ModDrop URLs.
  * Internal changes to improve performance and reliability.

* For mod authors:
  * Added [event priorities](https://stardewvalleywiki.com/Modding:Modder_Guide/APIs/Events#Custom_priority) (thanks to spacechase0!).
  * Added [update subkeys](https://stardewvalleywiki.com/Modding:Modder_Guide/APIs/Update_checks#Update_subkeys).
  * Added [a custom build of Harmony](https://github.com/Pathoschild/Harmony#readme) to provide more useful stack traces in error logs.
  * Added `harmony_summary` console command to list or search current Harmony patches.
  * Added `Multiplayer.PeerConnected` event.
  * Added support for overriding update keys from the wiki compatibility list.
  * Improved mod rewriting for compatibility to support more cases (e.g. custom attributes and generic types).
  * Fixed `helper.Reflection` blocking access to game methods/properties intercepted by SMAPI.
  * Fixed asset propagation for Gil's portraits.
  * Fixed `.pdb` files ignored for error stack traces when mods are rewritten by SMAPI.
  * Fixed `ModMessageReceived` event handlers not tracked for performance monitoring.

* For SMAPI developers:
  * Eliminated MongoDB storage in the web services, which complicated the code unnecessarily. The app still uses an abstract interface for storage, so we can wrap a distributed cache in the future if needed.
  * Overhauled update checks to simplify mod site integrations, centralize common logic, and enable upcoming features.
  * Merged the separate legacy redirects app on AWS into the main app on Azure.
  * Changed SMAPI's Harmony ID from `io.smapi` to `SMAPI` for readability in Harmony summaries.

## 3.5.0
Released 27 April 2020 for Stardew Valley 1.4.1 or later. See [release highlights](https://www.patreon.com/posts/36471055).

* For players:
  * SMAPI now prevents more game errors due to broken items, so you no longer need save editing to remove them.
  * Added option to disable console colors.
  * Updated compatibility list.
  * Improved translations.¹

* For the Console Commands mod:
  * Commands like `world_setday` now also affect the 'days played' stat, so in-game events/randomization match what you'd get if you played to that date normally (thanks to kdau!).

* For the web UI:
  * Updated the JSON validator/schema for Content Patcher 1.13.
  * Fixed rare intermittent "CGI application encountered an error" errors.

* For mod authors:
  * Added map patching to the content API (via `asset.AsMap()`).
  * Added support for using patch helpers with arbitrary data (via `helper.Content.GetPatchHelper`).
  * Added `SDate` fields/methods: `SeasonIndex`, `FromDaysSinceStart`, `FromWorldDate`, `ToWorldDate`, and `ToLocaleString` (thanks to kdau!).
  * Added `SDate` translations taken from the Lookup Anything mod.¹
  * Fixed asset propagation for certain maps loaded through temporary content managers. This notably fixes unreliable patches to the farmhouse and town maps.
  * Fixed asset propagation on Linux/macOS for monster sprites, NPC dialogue, and NPC schedules.
  * Fixed asset propagation for NPC dialogue sometimes causing a spouse to skip marriage dialogue or not allow kisses.

¹ Date format translations were taken from the Lookup Anything mod; thanks to translators FixThisPlz (improved Russian), LeecanIt (added Italian), pomepome (added Japanese), S2SKY (added Korean), Sasara (added German), SteaNN (added Russian), ThomasGabrielDelavault (added Spanish), VincentRoth (added French), Yllelder (improved Spanish), and yuwenlan (added Chinese). Some translations for Korean, Hungarian, and Turkish were derived from the game translations.

## 3.4.1
Released 24 March 2020 for Stardew Valley 1.4.1 or later.

* For mod authors:
  * Asset changes now propagate to NPCs in an event (e.g. wedding sprites).
  * Fixed mouse input suppression not working in SMAPI 3.4.

## 3.4.0
Released 22 March 2020 for Stardew Valley 1.4.1 or later. See [release highlights](https://www.patreon.com/posts/35161371).

* For players:
  * Fixed semi-transparency issues on Linux/macOS in recent versions of Mono (e.g. pink shadows).
  * Fixed `player_add` command error if you have broken XNB mods.
  * Removed invalid-location check now handled by the game.
  * Updated translations. Thanks to Annosz (added Hungarian)!

* For mod authors:
  * Added support for flipped and rotated map tiles (thanks to collaboration with Platonymous!).
  * Added support for `.tmx` maps using zlib compression (thanks to Platonymous!).
  * Added `this.Monitor.LogOnce` method.
  * Mods are no longer prevented from suppressing key presses in the chatbox.

* For the web UI:
  * Added option to upload files using a file picker.
  * Optimized log parser for very long multi-line log messages.
  * Fixed log parser not detecting folder path in recent versions of SMAPI.

* For SMAPI developers:
  * Added internal API to send custom input to the game/mods. This is mainly meant to support Virtual Keyboard on Android, but might be exposed as a public API in future versions.

## 3.3.2
Released 22 February 2020 for Stardew Valley 1.4.1 or later.

* Fixed mods receiving their own message broadcasts.

## 3.3.1
Released 22 February 2020 for Stardew Valley 1.4.1 or later.

* Fixed errors with custom spouse room mods in SMAPI 3.3.

## 3.3.0
Released 22 February 2020 for Stardew Valley 1.4.1 or later. See [release highlights](https://www.patreon.com/posts/34248719).

* For players:
  * Improved performance for mods which load many images.
  * Reduced network traffic for mod broadcasts to players who can't process them.
  * Fixed update-check errors for recent versions of SMAPI on Android.
  * Updated draw logic to match recent game updates.
  * Updated compatibility list.
  * Updated SMAPI/game version map.
  * Updated translations. Thanks to xCarloC (added Italian)!

* For the Save Backup mod:
  * Fixed warning on macOS when you have no saves yet.
  * Reduced log messages.

* For the web UI:
  * Updated the JSON validator and Content Patcher schema for `.tmx` support.
  * The mod compatibility page now has a sticky table header.

* For mod authors:
  * Added support for [message sending](https://stardewvalleywiki.com/Modding:Modder_Guide/APIs/Integrations#Message_sending) to mods on the current computer (in addition to remote computers).
  * Added `ExtendImage` method to content API when editing files to resize textures.
  * Added `helper.Input.GetState` to get the low-level state of a button.
  * **[Breaking change]** Map tilesheets are no loaded from `Content` if they can't be found in `Content/Maps`. This reflects an upcoming change in the game to delete duplicate map tilesheets under `Content`. Most mods should be unaffected.
  * Improved map tilesheet errors so they provide more info.
  * When mods load an asset using a more general type like `content.Load<object>`, SMAPI now calls `IAssetEditor` instances with the actual asset type instead of the specified one.
  * Updated dependencies (including Mono.Cecil 0.11.1 → 0.11.2).
  * Fixed dialogue propagation clearing marriage dialogue.

* For SMAPI/tool developers:
  * Improved support for four-part versions to support SMAPI on Android.
  * The SMAPI log now prefixes the OS name with `Android` on Android.

## 3.2.0
Released 01 February 2020 for Stardew Valley 1.4.1 or later. See [release highlights](https://www.patreon.com/posts/33659728).

* For players:
  * SMAPI now prevents crashes due to invalid schedule data.
  * SMAPI now prevents crashes due to invalid building types.
  * Added support for persistent `smapi-internal/config.json` overrides (see info in the file).
  * Updated minimum game version (1.4 → 1.4.1).
  * Fixed 'collection was modified' error when returning to title in rare cases.
  * Fixed error when update-checking a mod with a Chucklefish page that has no version.
  * Fixed rare error when building/demolishing buildings.
  * Fixed SMAPI beta versions not showing update alert on next launch (thanks to danvolchek!).

* For the Console Commands mod:
  * Added `performance` command to track mod performance metrics. This is an advanced experimental feature. (Thanks to Drachenkätzchen!)
  * Added `test_input` command to view button codes in the console.

* For the Save Backup mod:
  * Fixed extra files under `Saves` (e.g. manual backups) not being ignored.
  * Fixed Android issue where game files were backed up.

* For mod authors:
  * Added support for `.tmx` map files. (Thanks to [Platonymous for the underlying library](https://github.com/Platonymous/TMXTile)!)
  * Added special handling for `Vector2` values in `.json` files, so they work consistently crossplatform.
  * Reworked the order that asset editors/loaders are called between multiple mods to support some framework mods like Content Patcher and Json Assets. Note that the order is undefined and should not be depended on.
  * Fixed incorrect warning about mods adding invalid schedules in some cases. The validation was unreliable, and has been removed.
  * Fixed asset propagation not updating other players' sprites.
  * Fixed asset propagation for player sprites not updating recolor maps (e.g. sleeves).
  * Fixed asset propagation for marriage dialogue.
  * Fixed dialogue asset changes not correctly propagated until the next day.
  * Fixed `helper.Data.Read`/`WriteGlobalData` using the `Saves` folder instead of the game's appdata folder. The installer will move existing folders automatically.
  * Fixed issue where a mod which implemented `IAssetEditor`/`IAssetLoader` on its entry class could then remove itself from the editor/loader list.

* For SMAPI/tool developers:
  * Added internal performance monitoring (thanks to Drachenkätzchen!). This is disabled by default in the current version, but can be enabled using the `performance` console command.
  * Added internal support for four-part versions to support SMAPI on Android.
  * Rewrote `SemanticVersion` parsing.
  * Updated links for the new r/SMAPI subreddit.
  * The `/mods` web API endpoint now includes version mappings from the wiki.
  * Dropped API support for the pre-3.0 update-check format.

## 3.1.0
Released 05 January 2019 for Stardew Valley 1.4.1 or later. See [release highlights](https://www.patreon.com/posts/32904041).

* For players:
  * Added separate group in 'skipped mods' list for broken dependencies, so it's easier to see what to fix first.
  * Added friendly log message for save file-not-found errors.
  * Updated for gamepad modes in Stardew Valley 1.4.1.
  * Improved performance in some cases.
  * Fixed compatibility with Linux Mint 18 (thanks to techge!), Arch Linux, and Linux systems with libhybris-utils installed.
  * Fixed memory leak when repeatedly loading a save and returning to title.
  * Fixed memory leak when mods reload assets.
  * Updated translations. Thanks to L30Bola (added Portuguese), PlussRolf (added Spanish), and shirutan (added Japanese)!

* For the Console Commands mod:
  * Added new clothing items.
  * Fixed spawning new flooring and rings (thanks to Mizzion!).
  * Fixed spawning custom rings added by mods.
  * Fixed errors when some item data is invalid.

* For the web UI:
  * Added option to edit & reupload in the JSON validator.
  * File uploads are now stored in Azure storage instead of Pastebin, due to ongoing Pastebin perfomance issues.
  * File uploads now expire after one month.
  * Updated the JSON validator for Content Patcher 1.10 and 1.11.
  * Fixed JSON validator no longer letting you change format when viewing a file.
  * Fixed JSON validator for Content Patcher not requiring `Default` if `AllowBlank` was omitted.
  * Fixed log parser not correctly handling content packs with no author (thanks to danvolchek!).
  * Fixed main sidebar link pointing to wiki instead of home page.

* For mod authors:
  * Added `World.ChestInventoryChanged` event (thanks to collaboration with wartech0!).
  * Added asset propagation for...
    * grass textures;
    * winter flooring textures;
    * `Data\Bundles` changes (for added bundles only);
    * `Characters\Farmer\farmer_girl_base_bald`.
  * Added paranoid-mode warning for direct `Console` access.
  * Improved error messages for `TargetParameterCountException` when using the reflection API.
  * `helper.Read/WriteSaveData` can now be used while a save is being loaded (e.g. within a `Specialized.LoadStageChanged` event).
  * Removed `DumpMetadata` option. It was only for specific debugging cases, but players would sometimes enable it incorrectly and then report crashes.
  * Fixed private textures loaded from content packs not having their `Name` field set.

* For SMAPI developers:
  * You can now run local environments without configuring Amazon, Azure, MongoDB, and Pastebin accounts.

## 3.0.1
Released 02 December 2019 for Stardew Valley 1.4 or later.

* For players:
  * Updated for Stardew Valley 1.4.0.1.
  * Improved compatibility with some Linux terminals (thanks to archification and DanielHeath!).
  * Updated translations. Thanks to berkayylmao (added Turkish), feathershine (added Chinese), and Osiris901 (added Russian)!

* For the web UI:
  * Rebuilt web infrastructure to handle higher traffic.
  * If a log can't be uploaded to Pastebin (e.g. due to rate limits), it's now uploaded to Amazon S3 instead. Logs uploaded to S3 expire after one month.
  * Fixed JSON validator not letting you drag & drop a file.

* For mod authors:
  * `SemanticVersion` now supports [semver 2.0](https://semver.org/) build metadata.

## 3.0.0
Released 26 November 2019 for Stardew Valley 1.4.

### Release highlights
For players:
* **Updated for Stardew Valley 1.4.**  
  SMAPI 3.0 adds compatibility with the latest game version, and improves mod APIs for changes in
  the game code.

* **Improved performance.**  
  SMAPI should have less impact on game performance and startup time for some players.

* **Automatic save fixing and more error recovery.**  
  SMAPI now detects and prevents more crashes due to game/mod bugs, and automatically fixes your
  save if you remove some custom-content mods.

* **Improved mod scanning.**  
  SMAPI now supports some non-standard mod structures automatically, improves compatibility with
  the Vortex mod manager, and improves various error/skip messages related to mod loading.

* **Overhauled update checks.**  
  SMAPI update checks are now handled entirely on the web server and support community-defined
  version mappings. In particular, false update alerts due to author mistakes can now be solved by
  the community for all players.

* **Fixed many bugs and edge cases.**

For mod authors:
* **New event system.**  
  SMAPI 3.0 removes the deprecated static events in favor of the new `helper.Events` API. The event
  engine is rewritten to make events more efficient, add events that weren't possible before, make
  existing events more useful, and make event usage and behavior more consistent. When a mod makes
  changes in an event handler, those changes are now also reflected in the next event raise.

* **Improved mod build package.**  
  The [mod build package](https://www.nuget.org/packages/Pathoschild.Stardew.ModBuildConfig) now
  includes the `assets` folder by default if present, supports the new `.csproj` project format,
  enables mod `.pdb` files automatically (to provide line numbers in error messages), adds optional
  Harmony support, and fixes some bugs and edge cases. This also adds compatibility with SMAPI 3.0
  and Stardew Valley 1.4, and drops support for older versions.

* **Mods loaded earlier.**  
  SMAPI now loads mods much earlier, before the game is initialised. That lets mods do things that
  were difficult before, like intercepting some core assets.

* **Improved Android support.**  
  SMAPI now automatically detects when it's running on Android, and updates `Constants.TargetPlatform`
  so mods can adjust their logic if needed. The Save Backup mod is also now Android-compatible.

* **Improved asset propagation.**  
  SMAPI now automatically propagates asset changes for farm animal data, NPC default location data,
  critter textures, and `DayTimeMoneyBox` buttons. Every loaded texture now also has a `Name` field
  so mods can check which asset a texture was loaded for.

* **Breaking changes:**  
  See _[migrate to SMAPI 3.0](https://stardewvalleywiki.com/Modding:Migrate_to_SMAPI_3.0)_ and
  _[migrate to Stardew Valley 1.4](https://stardewvalleywiki.com/Modding:Migrate_to_Stardew_Valley_1.4)_
  for more info.

### For players
* Changes:
  * Updated for Stardew Valley 1.4.
  * Improved performance.
  * Reworked update checks and added community-defined version mapping, to reduce false update alerts due to author mistakes.
  * SMAPI now removes invalid locations/NPCs when loading a save to prevent crashes. A warning is shown in-game when this happens.
  * Added update checks for CurseForge mods.
  * Added support for editing console colors via `smapi-internal/config.json` (for players with unusual consoles).
  * Added support for setting SMAPI CLI arguments as environment variables for Linux/macOS compatibility.
  * Improved mod scanning:
    * Now ignores metadata files/folders (like `__MACOSX` and `__folder_managed_by_vortex`) and content files (like `.txt` or `.png`), which avoids missing-manifest errors in some cases.
    * Now detects XNB mods more accurately, and consolidates multi-folder XNB mods in logged messages.
  * Improved launch script compatibility on Linux (thanks to kurumushi and toastal!).
  * Made error messages more user-friendly in some cases.
  * Save Backup now works in the background, to avoid affecting startup time for players with a large number of saves.
  * The installer now recognises custom game paths stored in [`stardewvalley.targets`](http://smapi.io/package/custom-game-path).
  * Duplicate-mod errors now show the mod version in each folder.
  * Update checks are now faster in some cases.
  * Updated mod compatibility list.
  * Updated SMAPI/game version map.
  * Updated translations. Thanks to eren-kemer (added German)!
* Fixes:
  * Fixed some assets not updated when you switch language to English.
  * Fixed lag in some cases due to incorrect asset caching when playing in non-English.
  * Fixed lag when a mod invalidates many NPC portraits/sprites at once.
  * Fixed Console Commands not including upgraded tools in item commands.
  * Fixed Console Commands' item commands failing if a mod adds invalid item data.
  * Fixed Save Backup not pruning old backups if they're uncompressed.
  * Fixed issues when a farmhand reconnects before the game notices they're disconnected.
  * Fixed 'received message' logs shown in non-developer mode.
  * Fixed various error messages and inconsistent spelling.
  * Fixed update-check error if a Nexus mod is marked as adult content.
  * Fixed update-check error if the Chucklefish page for an update key doesn't exist.

### For the web UI
* Mod compatibility list:
  * Added support for CurseForge mods.
  * Added metadata links and dev notes (if any) to advanced info.
  * Now loads faster (since data is fetched in a background service).
  * Now continues working with cached data when the wiki is offline.
  * Clicking a mod link now automatically adds it to the visible mods if the list is filtered.

* JSON validator:
  * Added JSON validator at [smapi.io/json](https://smapi.io/json), which lets you validate a JSON file against predefined mod formats.
  * Added support for the `manifest.json` format.
  * Added support for the Content Patcher format (thanks to TehPers!).
  * Added support for referencing a schema in a JSON Schema-compatible text editor.

* For the log parser:
  * Added instructions for Android.
  * The page now detects your OS and preselects the right instructions (thanks to danvolchek!).

### For mod authors
* Breaking changes:
  * Mods are now loaded much earlier in the game launch. This lets mods intercept any content asset, but the game is not fully initialized when `Entry` is called; use the `GameLaunched` event if you need to run code when the game is initialized.
  * Removed all deprecated APIs.
  * Removed unused APIs: `Monitor.ExitGameImmediately`, `Translation.ModName`, and `Translation.Assert`.
  * Fixed `ICursorPosition.AbsolutePixels` not adjusted for zoom.
  * `SemanticVersion` no longer omits `.0` patch numbers when formatting versions, for better [semver](https://semver.org/) conformity (e.g. `3.0` is now formatted as `3.0.0`).
* Changes:
  * Added support for content pack translations.
  * Added `IContentPack.HasFile`, `Context.IsGameLaunched`, and `SemanticVersion.TryParse`.
  * Added separate `LogNetworkTraffic` option to make verbose logging less overwhelmingly verbose.
  * Added asset propagation for `Data\FarmAnimals`, critter textures, and `DayTimeMoneyBox` buttons.
  * Added `Texture2D.Name` values set to the asset key.
  * Added trace logs for skipped loose files in the `Mods` folder and custom SMAPI settings so it's easier to troubleshoot player logs.
  * `Constants.TargetPlatform` now returns `Android` when playing on an Android device.
  * Trace logs for a broken mod now list all detected issues (instead of the first one).
  * Trace logs when loading mods are now more clear.
  * Clarified update-check errors for mods with multiple update keys.
  * Updated dependencies (including Json.NET 11.0.2 → 12.0.3 and Mono.Cecil 0.10.1 → 0.11.1).
* Fixes:
  * Fixed map reloads resetting tilesheet seasons.
  * Fixed map reloads not updating door warps.
  * Fixed outdoor tilesheets being seasonalised when added to an indoor location.
  * Fixed mods needing to load custom `Map` assets before the game accesses them. SMAPI now does so automatically.
  * Fixed custom maps loaded from `.xnb` files not having their tilesheet paths automatically adjusted.
  * Fixed custom maps loaded from the mod folder with tilesheets in a subfolder not working crossplatform. All tilesheet paths are now normalized for the OS automatically.
  * Fixed issue where mod changes weren't tracked correctly for raising events in some cases. Events now reflect a frozen snapshot of the game state, and any mod changes are reflected in the next event tick.
  * Fixed issue where, when a mod's `IAssetEditor` uses `asset.ReplaceWith` on a texture asset while playing in non-English, any changes from that point forth wouldn't affect subsequent cached asset loads.
  * Fixed asset propagation for NPC portraits resetting any unique portraits (e.g. Maru's hospital portrait) to the default.
  * Fixed changes to `Data\NPCDispositions` not always propagated correctly to existing NPCs.
  * Fixed `Rendering`/`Rendered` events not raised during minigames.
  * Fixed `LoadStageChanged` event not raising correct flags in some cases when creating a new save.
  * Fixed `GetApi` without an interface not checking if all mods are loaded.

### For SMAPI maintainers
* Added support for core translation files.
* Migrated to new `.csproj` format.
* Internal refactoring.

## 2.11.3
Released 13 September 2019 for Stardew Valley 1.3.36.

* For players:
  * SMAPI now prevents invalid items from breaking menus on hover.
  * SMAPI now prevents invalid event preconditions from crashing the game (thanks to berkayylmao!).
  * SMAPI now prevents more invalid dialogue from crashing the game.
  * Fixed errors during early startup not shown before exit.
  * Fixed various error messages and inconsistent spelling.

* For the web UI:
  * When filtering the mod list, clicking a mod link now automatically adds it to the visible mods.
  * Added log parser instructions for Android.
  * Fixed log parser failing in some cases due to time format localization.

* For mod authors:
  * `this.Monitor.Log` now defaults to the `Trace` log level instead of `Debug`. The change will only take effect when you recompile the mod.
  * Fixed 'location list changed' verbose log not correctly listing changes.
  * Fixed mods able to directly load (and in some cases edit) a different mod's local assets using internal asset key forwarding.
  * Fixed changes to a map loaded by a mod being persisted across content managers.
  * Fixed `SDate.AddDays` incorrectly changing year when the result is exactly winter 28.

## 2.11.2
Released 23 April 2019 for Stardew Valley 1.3.36.

* For players:
  * Fixed error when a custom map references certain vanilla tilesheets on Linux/macOS.
  * Fixed compatibility with some Linux distros.

## 2.11.1
Released 17 March 2019 for Stardew Valley 1.3.36.

* For players:
  * Added crops option to `world_clear` console command.
  * Prepared compatibility check for Stardew Valley 1.4.
  * Updated mod compatibility list.
  * Fixed `world_clear` console command removing chests edited to have a debris name.

* For mod authors:
  * Added support for suppressing false-positive warnings in rare cases.

* For the web UI:
  * The log parser now collapses redundant sections by default.
  * Fixed log parser column resize bug.

## 2.11.0
Released 01 March 2019 for Stardew Valley 1.3.36.

* For players:
  * Updated for Stardew Valley 1.3.36.

* For mod authors:
  * Bumped all deprecation levels to _pending removal_.

* For the web UI:
  * The log parser now shows available updates in a section at the top.
  * The mod compatibility page now crosses out mod links if they're outdated to avoid confusion.
  * Fixed smapi.io linking to an archived download in rare cases.

## 2.10.2
Released 09 January 2019 for Stardew Valley 1.3.32–33.

* For players:
  * SMAPI now keeps the first save backup created for the day, instead of the last one.
  * Fixed save backup for some Linux/macOS players. (When compression isn't available, SMAPI will now create uncompressed backups instead.)
  * Fixed some common dependencies not linking to the mod page in 'missing mod' errors.
  * Fixed 'unknown mod' deprecation warnings showing a stack trace when developers mode not enabled.
  * Fixed 'unknown mod' deprecation warnings when they occur in the Mod constructor.
  * Fixed confusing error message when using SMAPI 2.10._x_ with Stardew Valley 1.3.35+.
  * Tweaked XNB mod message for clarity.
  * Updated compatibility list.

* For the web UI:
  * Added beta status filter to compatibility list.
  * Fixed broken ModDrop links in the compatibility list.

* For mod authors:
  * Asset changes are now propagated into the parsed save being loaded if applicable.
  * Added locale to context trace logs.
  * Fixed error loading custom map tilesheets in some cases.
  * Fixed error when swapping maps mid-session for a location with interior doors.
  * Fixed `Constants.SaveFolderName` and `CurrentSavePath` not available during early load stages when using `Specialized.LoadStageChanged` event.
  * Fixed `LoadStage.SaveParsed` raised before the parsed save data is available.
  * Fixed 'unknown mod' deprecation warnings showing the wrong stack trace.
  * Fixed `e.Cursor` in input events showing wrong grab tile when player using a controller moves without moving the viewpoint.
  * Fixed incorrect 'bypassed safety checks' warning for mods using the new `Specialized.LoadStageChanged` event in 2.10.
  * Deprecated `EntryDll` values whose capitalization don't match the actual file. (This works on Windows, but causes errors for Linux/macOS players.)

## 2.10.1
Released 30 December 2018 for Stardew Valley 1.3.32–33.

* For players:
  * Fixed some mod integrations not working correctly in SMAPI 2.10.

## 2.10.0
Released 29 December 2018 for Stardew Valley 1.3.32–33.

* For players:
  * Added `world_clear` console command to remove spawned or placed entities.
  * Minor performance improvements.
  * Tweaked installer to reduce antivirus false positives.

* For mod authors:
  * Added [events](https://stardewvalleywiki.com/Modding:Modder_Guide/APIs/Events): `GameLoop.OneSecondUpdateTicking`, `GameLoop.OneSecondUpdateTicked`, and `Specialized.LoadStageChanged`.
  * Added `e.IsCurrentLocation` event arg to `World` events.
  * You can now use `helper.Data.Read/WriteSaveData` as soon as the save is loaded (instead of once the world is initialized).
  * Increased deprecation levels to _info_ for the upcoming SMAPI 3.0.

* For the web UI:
  * Reduced mod compatibility list's cache time.

## 2.9.3
Released 16 December 2018 for Stardew Valley 1.3.32.

* For players:
  * Fixed errors hovering items in some cases with SMAPI 2.9.2.
  * Fixed some multiplayer features broken when a farmhand returns to title and rejoins.

## 2.9.2
Released 16 December 2018 for Stardew Valley 1.3.32.

* For players:
  * SMAPI now prevents invalid items from crashing the game on hover.
  * Fixed some multiplayer features broken when connecting via Steam friends.
  * Fixed cryptic error message when the game isn't installed correctly.
  * Fixed error when a mod makes invalid changes to an NPC schedule.
  * Fixed game launch errors logged as `SMAPI` instead of `game`.
  * Fixed Windows installer adding unneeded Unix launcher to game folder.

* For mod authors:
  * Moved content pack methods into a new [content pack API](https://stardewvalleywiki.com/Modding:Modder_Guide/APIs/Content_Packs).
  * Fixed invalid NPC data propagated when a mod changes NPC dispositions.
  * Fixed `Display.RenderedWorld` event broken in SMAPI 2.9.1.
  * **Deprecations:**
    * The `assetData.AsDictionary<TKey, TValue>().Set` methods are now deprecated. Mods should access the `Data` property directly instead.
    * The content pack methods directly on `helper` are now deprecated. Mods should use `helper.ContentPacks` instead.

* For SMAPI developers:
  * Added SMAPI 3.0 readiness to mod API data.

## 2.9.1
Released 07 December 2018 for Stardew Valley 1.3.32.

* For players:
  * Fixed crash in SMAPI 2.9 when constructing certain buildings.
  * Fixed error when a map asset is reloaded in rare cases.

## 2.9.0
Released 07 December 2018 for Stardew Valley 1.3.32.

* For players:
  * Added support for ModDrop in update checks and the mod compatibility list.
  * Added friendly error for Steam players when Steam isn't loaded.
  * Fixed cryptic error when running the installer from inside a zip file on Windows.
  * Fixed error when leaving and rejoining a multiplayer server in the same session.
  * Fixed empty "mods with warnings" list in some cases due to hidden warnings.
  * Fixed Console Commands' handling of tool upgrade levels for item commands.

* For mod authors:
  * Added ModDrop update keys (see [docs](https://stardewvalleywiki.com/Modding:Modder_Guide/APIs/Manifest#Update_checks)).
  * Added `IsLocalPlayer` to new player events.
  * Added `helper.CreateTemporaryContentPack` to replace the deprecated `CreateTransitionalContentPack`.
  * Reloading a map asset will now update affected locations.
  * Reloading the `Data\NPCDispositions` asset will now update affected NPCs.
  * Disabled trace messages related to paranoid mode when it's disabled.
  * Fixed world events like `ObjectListChanged` not working in the mines.
  * Fixed some map tilesheets not editable if not playing in English.
  * Fixed newlines in manifest fields not being ignored.
  * Fixed `Display.RenderedWorld` event invoked after overlays are rendered.
  * **Deprecations:**
    * All static events are deprecated and will be removed in SMAPI 3.0. Mods should use the new event system available through `helper.Events` instead; see [_migrate to SMAPI 3.0_](https://stardewvalleywiki.com/Modding:Migrate_to_SMAPI_3.0) for details.

* For the web UI:
  * Added stats to compatibility list.
  * Fixed compatibility list showing beta header when there's no beta in progress.

## 2.8.2
Released 19 November 2018 for Stardew Valley 1.3.32.

* Fixed game crash in macOS with SMAPI 2.8.

## 2.8.1
Released 19 November 2018 for Stardew Valley 1.3.32.

* Fixed installer error on Windows with SMAPI 2.8.

## 2.8.0
Released 19 November 2018 for Stardew Valley 1.3.32.

* For players:
  * Reorganised SMAPI files:
    * Moved most SMAPI files into a `smapi-internal` subfolder (so your game folder is less messy).
    * Moved save backups into a `save-backups` subfolder (so they're easier to find).
    * Simplified the installer files to avoid confusion.
  * Added support for organising mods into subfolders.
  * Added support for [ignoring mod folders](https://stardewvalleywiki.com/Modding:Player_Guide/Getting_Started#Install_mods).
  * Update checks now work even for mods without update keys in most cases.
  * SMAPI now prevents a crash caused by mods adding dialogue the game can't parse.
  * SMAPI now recommends a compatible SMAPI version if you have an older game version.
  * Improved various error messages to be more clear and intuitive.
  * Improved compatibility with various Linux shells (thanks to lqdev!), and prefer xterm when available.
  * Fixed transparency issues on Linux/macOS for some mod images.
  * Fixed error when a mod manifest is corrupted.
  * Fixed error when a mod adds an unnamed location.
  * Fixed friendly error no longer shown when SMAPI isn't run from the game folder.
  * Fixed some Windows install paths not detected.
  * Fixed installer duplicating bundled mods if you moved them after the last install.
  * Fixed installer allowing custom mods to be bundled with the install.
  * Fixed some translation issues not shown as warnings.
  * Fixed dependencies not correctly enforced if the dependency is installed but failed to load.
  * Fixed some errors logged as SMAPI instead of the affected mod.
  * Fixed crash log deleted immediately when you relaunch the game.
  * Updated compatibility list.

* For the web UI:
  * Added a [mod compatibility page](https://smapi.io/mods) and [privacy page](https://smapi.io/privacy).
  * The log parser now has a separate filter for game messages.
  * The log parser now shows content pack authors (thanks to danvolchek!).
  * Tweaked log parser UI (thanks to danvolchek!).
  * Fixed log parser instructions for macOS.

* For mod authors:
  * Added [data API](https://stardewvalleywiki.com/Modding:Modder_Guide/APIs/Data) to store mod data in the save file or app data.
  * Added [multiplayer API](https://stardewvalleywiki.com/Modding:Modder_Guide/APIs/Multiplayer) and [events](https://stardewvalleywiki.com/Modding:Modder_Guide/Apis/Events#Multiplayer_2) to send/receive messages and get connected player info.
  * Added [verbose logging](https://stardewvalleywiki.com/Modding:Modder_Guide/APIs/Logging#Verbose_logging) feature.
  * Added `IContentPack.WriteJsonFile` method.
  * Added IntelliSense documentation for the non-developers version of SMAPI.
  * Added more events to the prototype `helper.Events` for SMAPI 3.0.
  * Added `SkillType` enum constant.
  * Improved content API:
    * added support for overlaying image assets with semi-transparency;
    * mods can now load PNGs even if the game is currently drawing.
  * When comparing mod versions, SMAPI now assigns the lowest precedence to `-unofficial` (e.g. `1.0-beta > 1.0-unofficial`).
  * Fixed content packs' `ReadJsonFile` allowing non-relative paths.
  * Fixed content packs always failing to load if they declare a dependency on a SMAPI mod.
  * Fixed trace logs not showing path for invalid mods.
  * Fixed 'no update keys' warning not shown for mods with only invalid update keys.
  * Fixed `Context.IsPlayerFree` being true while the player is mid-warp in multiplayer.
  * Fixed update-check errors sometimes being overwritten with a generic message.
  * Suppressed the game's 'added crickets' debug output.
  * Updated dependencies (Harmony 1.0.9.1 → 1.2.0.1, Mono.Cecil 0.10 → 0.10.1).
  * **Deprecations:**
    * Non-string manifest versions are now deprecated and will stop working in SMAPI 3.0. Affected mods should use a string version, like `"Version": "1.0.0"`.
    * `ISemanticVersion.Build` is now deprecated and will be removed in SMAPI 3.0. Affected mods should use `ISemanticVersion.PrereleaseTag` instead.
  * **Breaking changes:**
    * `helper.ModRegistry` now returns `IModInfo` instead of `IManifest` directly. This lets SMAPI return more metadata about mods. This doesn't affect any mods that didn't already break in Stardew Valley 1.3.32.
    * Most SMAPI files have been moved into a `smapi-internal` subfolder. This won't affect compiled mod releases, but you'll need to update the build config NuGet package.

* For SMAPI developers:
  * Added support for parallel stable/beta unofficial updates in update checks.
  * Added a 'paranoid warnings' option which reports mods using potentially sensitive .NET APIs (like file or shell access) in the mod issues list.
  * Adjusted `SaveBackup` mod to make it easier to account for custom mod subfolders in the installer.
  * Installer no longer special-cases Omegasis' older `SaveBackup` mod (now named `AdvancedSaveBackup`).
  * Fixed mod web API returning a concatenated name for mods with alternate names.

## 2.7.0
Released 14 August 2018 for Stardew Valley 1.3.28.

* For players:
  * Updated for Stardew Valley 1.3.28.
  * Improved how mod issues are listed in the console and log.
  * Revamped installer. It now...
    * uses a new format that should be more intuitive;
    * lets players on Linux/macOS choose the console color scheme (SMAPI will auto-detect it on Windows);
    * and validates requirements earlier.
  * Fixed custom festival maps always using spring tilesheets.
  * Fixed `player_add` command not recognising return scepter.
  * Fixed `player_add` command showing fish twice.
  * Fixed some SMAPI logs not deleted when starting a new session.
  * Updated compatibility list.

* For mod authors:
  * Added support for `.json` data files in the content API (including Content Patcher).
  * Added propagation for asset changes through the content API for...
    * child sprites;
    * dialogue;
    * map tilesheets.
  * Added `--mods-path` CLI command-line argument to switch between mod folders.
  * All enums are now JSON-serialized by name instead of numeric value. (Previously only a few enums were serialized that way. JSON files which already have numeric enum values will still be parsed fine.)
  * Fixed false compatibility error when constructing multidimensional arrays.
  * Fixed `.ToSButton()` methods not being public.

* For SMAPI developers:
  * Dropped support for pre-SMAPI-2.6 update checks in the web API.  
    _These are no longer useful, even if the player still has earlier versions of SMAPI. Older versions of SMAPI won't launch in Stardew Valley 1.3 (so they won't check for updates), and newer versions of SMAPI/mods won't work with older versions of the game._

## 2.6.0
Released 01 August 2018 for Stardew Valley 1.3.27.

* For players:
  * Updated for Stardew Valley 1.3.
  * Added automatic save backups.
  * Improved update checks:
    * added beta update channel;
    * added update alerts for incompatible mods with an unofficial update on the wiki;
    * added update alerts for optional files on Nexus;
    * added console warning for mods which don't have update checks configured;
    * added more visible prompt in beta channel for SMAPI updates;
    * fixed mod update checks failing if a mod only has prerelease versions on GitHub;
    * fixed Nexus mod update alerts not showing HTTPS links.
  * Improved mod warnings in the console.
  * Improved error when game can't start audio.
  * Improved the Console Commands mod:
    * Added `player_add name`, which adds items to your inventory by name instead of ID.
    * Fixed `world_setseason` not running season-change logic.
    * Fixed `world_setseason` not normalizing the season value.
    * Fixed `world_settime` sometimes breaking NPC schedules (e.g. so they stay in bed).
    * Removed the `player_setlevel` and `player_setspeed` commands, which weren't implemented in a useful way. Use a mod like CJB Cheats Menu if you need those.
  * Fixed `SEHException` errors for some players.
  * Fixed performance issues for some players.
  * Fixed default color scheme on macOS or in PowerShell (configurable via `StardewModdingAPI.config.json`).
  * Fixed installer error on Linux/macOS in some cases.
  * Fixed installer not finding some game paths or showing duplicate paths.
  * Fixed installer not removing some SMAPI files.
  * Fixed launch issue for Linux players with some terminals. (Thanks to HanFox and kurumushi!)
  * Fixed abort-retry loop if a mod crashed when intercepting assets during startup.
  * Fixed some mods failing if the player name is blank.
  * Fixed errors when a mod references a missing assembly.
  * Fixed `AssemblyResolutionException` errors in rare cases.
  * Renamed `install.exe` to `install on Windows.exe` to avoid confusion.
  * Updated compatibility list.

* For the web UI:
  * Added option to download SMAPI from Nexus.
  * Added log parser redesign that should be more intuitive.
  * Added log parser option to view raw log.
  * Changed log parser filters to show `DEBUG` messages by default.
  * Fixed design on smaller screens.
  * Fixed log parser issue when content packs have no description.
  * Fixed log parser mangling crossplatform paths in some cases.
  * Fixed `smapi.io/install` not linking to a useful page.

* For mod authors:
  * Added [input API](https://stardewvalleywiki.com/Modding:Modder_Guide/APIs/Input) for reading and suppressing keyboard, controller, and mouse input.
  * Added code analysis in the NuGet package to flag common issues as warnings.
  * Replaced `LocationEvents` to support multiplayer:
    * now raised for all locations;
    * now includes added/removed building interiors;
    * each event now provides a list of added/removed values;
    * added buildings-changed event.
  * Added `Context.IsMultiplayer` and `Context.IsMainPlayer` flags.
  * Added `Constants.TargetPlatform` which says whether the game is running on Linux, macOS, or Windows.
  * Added `semanticVersion.IsPrerelease()` method.
  * Added support for launching multiple instances transparently. This removes the former `--log-path` command-line argument.
  * Added support for custom seasonal tilesheets when loading an unpacked `.tbin` map.
  * Added Harmony DLL for internal use by SMAPI. (Mods should still include their own copy for backwards compatibility, and in case it's removed later. SMAPI will always load its own version though.)
  * Added option to suppress update checks for a specific mod in `StardewModdingAPI.config.json`.
  * Added absolute pixels to `ICursorPosition`.
  * Added support for reading/writing `ISemanticVersion` to JSON.
  * Added support for reloading NPC schedules through the content API.
  * Reimplemented the content API so it works more reliably in many edge cases.
  * Reimplemented input suppression to work more consistently in many cases.
  * The order of update keys now affects which URL players see in update alerts.
  * Fixed assets loaded by temporary content managers not being editable by mods.
  * Fixed assets not reloaded consistently when the player switches language.
  * Fixed error if a mod loads a PNG while the game is loading (e.g. custom map tilesheets via `IAssetLoader`).
  * Fixed error if a mod translation file is empty.
  * Fixed input suppression not working consistently for clicks.
  * Fixed console input not saved to the log.
  * Fixed `Context.IsPlayerFree` being false during festivals.
  * Fixed `helper.ModRegistry.GetApi` errors not always mentioning which interface caused the issue.
  * Fixed console commands being invoked asynchronously.
  * Fixed mods able to intercept other mods' assets via the internal asset keys.
  * Fixed mods able to indirectly change other mods' data through shared content caches.
  * Fixed `SemanticVersion` allowing invalid versions in some cases.
  * **Breaking changes** (see [migration guide](https://stardewvalleywiki.com/Modding:Migrate_to_Stardew_Valley_1.3)):
     * Dropped some deprecated APIs.
     * `LocationEvents` have been rewritten.
     * Mods can't intercept chatbox input.
     * Mod IDs should only contain letters, numbers, hyphens, dots, and underscores. That allows their use in many contexts like URLs. This restriction is now enforced. (In regex form: `^[a-zA-Z0-9_.-]+$`.)

* For SMAPI developers:
  * Added more consistent crossplatform handling, including macOS detection.
  * Added beta update channel.
  * Added optional mod metadata to the web API (including Nexus info, wiki metadata, etc).
  * Added early prototype of SMAPI 3.0 events via `helper.Events`.
  * Added early prototype of mod handler toolkit.
  * Added Harmony for SMAPI's internal use.
  * Added metadata dump option in `StardewModdingAPI.config.json` for troubleshooting some cases.
  * Added more stylish pufferchick on the home page.
  * Rewrote update checks:
    * Moved most logic into the web API.
    * Changed web API to require mod IDs.
    * Changed web API to also fetch metadata from SMAPI's internal mod DB and the wiki.
  * Rewrote world/player state tracking. The new implementation is much more efficient than previous method, uses net field events where available, and lays the groundwork for more advanced events in SMAPI 3.0.
  * Split mod DB out of `StardewModdingAPI.config.json` into its own file.
  * Updated to Mono.Cecil 0.10.

## 2.5.5
Released 11 April 2018 for Stardew Valley 1.2.30–1.2.33.

* For players:
  * Fixed mod not loaded if it has an optional dependency that's loaded but skipped.
  * Fixed mod update alerts not shown if one mod has an invalid remote version.
  * Fixed SMAPI update alerts linking to the GitHub repository instead of [smapi.io](https://smapi.io).
  * Fixed SMAPI update alerts for draft releases.
  * Fixed error when two content packs use different capitalization for the same required mod ID.
  * Fixed rare crash if the game duplicates an item.

* For the [log parser](https://smapi.io/log):
  * Tweaked UI.

## 2.5.4
Released 26 March 2018 for Stardew Valley 1.2.30–1.2.33.

* For players:
  * Fixed some textures not updated when a mod changes them.
  * Fixed visual bug on Linux/macOS when mods overlay textures.
  * Fixed error when mods remove an asset editor/loader.
  * Fixed minimum game version incorrectly increased in SMAPI 2.5.3.

* For the [log parser](https://smapi.io/log):
  * Fixed error when log text contains certain tokens.

* For mod authors:
  * Updated to Json.NET 11.0.2.

* For SMAPI developers:
  * Added support for beta update track to support upcoming Stardew Valley 1.3 beta.

## 2.5.3
Released 13 March 2018 for Stardew Valley ~~1.2.30~~–1.2.33.

* For players:
  * Simplified and improved skipped-mod messages.
  * Fixed rare crash with some combinations of manifest fields and internal mod data.
  * Fixed update checks failing for Nexus Mods due to a change in their API.
  * Fixed update checks failing for some older mods with non-standard versions.
  * Fixed failed update checks being cached for an hour (now cached 5 minutes).
  * Fixed error when a content pack needs a mod that couldn't be loaded.
  * Fixed Linux ["magic number is wrong" errors](https://github.com/mono/mono/issues/6752) by changing default terminal order.
  * Updated compatibility list and added update checks for more mods.

* For the [log parser](https://smapi.io/log):
  * Fixed incorrect filtering in some cases.
  * Fixed error if mods have duplicate names.
  * Fixed parse bugs if a mod has no author name.

* For SMAPI developers:
  * Internal changes to support the upcoming Stardew Valley 1.3 update.

## 2.5.2
Released 25 February 2018 for Stardew Valley 1.2.30–1.2.33.

* For mod authors:
  * Fixed issue where replacing an asset through `asset.AsImage()` or `asset.AsDictionary()` didn't take effect.

* For the [log parser](https://smapi.io/log):
  * Fixed blank page after uploading a log in some cases.

## 2.5.1
Released 24 February 2018 for Stardew Valley 1.2.30–1.2.33.

* For players:
  * Fixed event error in rare cases.

## 2.5.0
Released 24 February 2018 for Stardew Valley 1.2.30–1.2.33.

* For players:
  * **Added support for [content packs](https://stardewvalleywiki.com/Modding:Content_packs)**.  
    <small>_Content packs are collections of files for a SMAPI mod to load. These can be installed directly under `Mods` like a normal SMAPI mod, get automatic update and compatibility checks, and provide convenient APIs to the mods that read them._</small>
  * Added mod detection for unhandled errors (so most errors now mention which mod caused them).
  * Added install scripts for Linux/macOS (no more manual terminal commands!).
  * Added the missing mod's name and URL to dependency errors.
  * Fixed uninstall script not reporting when done on Linux/macOS.
  * Updated compatibility list and enabled update checks for more mods.

* For mod authors:
  * Added support for content packs and new APIs to read them.
  * Added support for `ISemanticVersion` in JSON models.
  * Added `SpecializedEvents.UnvalidatedUpdateTick` event for specialized use cases.
  * Added path normalizing to `ReadJsonFile` and `WriteJsonFile` helpers (so no longer need `Path.Combine` with those).
  * Fixed deadlock in rare cases with asset loaders.
  * Fixed unhelpful error when a mod exposes a non-public API.
  * Fixed unhelpful error when a translation file has duplicate keys due to case-insensitivity.
  * Fixed some JSON field names being case-sensitive.

* For the [log parser](https://smapi.io/log):
  * Added support for SMAPI 2.5 content packs.
  * Reduced download size when viewing a parsed log with repeated errors.
  * Improved parse error handling.
  * Fixed 'log started' field showing incorrect date.

* For SMAPI developers:
  * Overhauled mod DB format to be more concise, reduce the memory footprint, and support versioning/defaulting more fields.
  * Reimplemented log parser with serverside parsing and vue.js on the frontend.

## 2.4.0
Released 24 January 2018 for Stardew Valley 1.2.30–1.2.33.

* For players:
  * Fixed visual map glitch in rare cases.
  * Fixed error parsing JSON files which have curly quotes.
  * Fixed error parsing some JSON files generated on another system.
  * Fixed error parsing some JSON files after mods reload core assemblies, which is no longer allowed.
  * Fixed intermittent errors (e.g. 'collection has been modified') with some mods when loading a save.
  * Fixed compatibility with Linux Terminator terminal.

* For the [log parser](https://smapi.io/log):
  * Fixed error parsing logs with zero installed mods.

* For mod authors:
  * Added `SaveEvents.BeforeCreate` and `AfterCreate` events.
  * Added `SButton` `IsActionButton()` and `IsUseToolButton()` extensions.
  * Improved JSON parse errors to provide more useful info for troubleshooting.
  * Fixed events being raised while the game is loading a save file.
  * Fixed input events not recognising controller input as an action or use-tool button.
  * Fixed input events setting the same `IsActionButton` and `IsUseToolButton` values for all buttons pressed in an update tick.
  * Fixed semantic versions ignoring `-0` as a prerelease tag.
  * Updated Json.NET to 11.0.1-beta3 (needed to avoid a parser edge case).

* For SMAPI developers:
  * Overhauled input handling to support future input events.

## 2.3.0
Released 26 December 2017 for Stardew Valley 1.2.30–1.2.33.

* For players:
  * Added a user-friendly [download page](https://smapi.io).
  * Improved cryptic libgdiplus errors on macOS when Mono isn't installed.
  * Fixed mod UIs hidden when menu backgrounds are enabled.

* For mod authors:
  * **Added mod-provided APIs** to allow simple integrations between mods, even without direct assembly references.
  * Added `GameEvents.FirstUpdateTick` event (called once after all mods are initialized).
  * Added `IsSuppressed` to input events so mods can optionally avoid handling keys another mod has already handled.
  * Added trace message for mods with no update keys.
  * Adjusted reflection API to match actual usage (e.g. renamed `GetPrivate*` to `Get*`), and deprecated previous methods.
  * Fixed `GraphicsEvents.OnPostRenderEvent` not being raised in some specialized cases.
  * Fixed reflection API error for properties missing a `get` and `set`.
  * Fixed issue where a mod could change the cursor position reported to other mods.
  * Updated compatibility list.

* For the [log parser](https://smapi.io/log):
  * Fixed broken favicon.

## 2.2.0
Released 02 December 2017 for Stardew Valley 1.2.30–1.2.33.

* For players:
  * Fixed error when a mod loads custom assets on Linux/macOS.
  * Fixed error when checking for updates on Linux/macOS due to API HTTPS redirect.
  * Fixed error when macOS adds an `mcs` symlink to the installer package.
  * Fixed `player_add` command not handling tool upgrade levels.
  * Improved error when a mod has an invalid `EntryDLL` filename format.
  * Updated compatibility list.

* For the [log parser](https://smapi.io/log):
  * Logs no longer expire after a week.
  * Fixed error when uploading very large logs.
  * Slightly improved the UI.

* For mod authors:
  * Added `helper.Content.NormalizeAssetName` method.
  * Added `SDate.DaysSinceStart` property.
  * Fixed input events' `e.SuppressButton(button)` method ignoring specified button.
  * Fixed input events' `e.SuppressButton()` method not working with mouse buttons.

## 2.1.0
Released 01 November 2017 for Stardew Valley 1.2.30–1.2.33.

* For players:
  * Added a [log parser](https://smapi.io/log) site.
  * Added better Steam instructions to the SMAPI installer.
  * Renamed the bundled _TrainerMod_ to _ConsoleCommands_ to make its purpose clearer.
  * Removed the game's test messages from the console log.
  * Improved update-check errors when playing offline.
  * Fixed compatibility check for players with Stardew Valley 1.08.
  * Fixed `player_setlevel` command not setting XP too.

* For mod authors:
  * The reflection API now works with public code to simplify mod integrations.
  * The content API now lets you invalidated multiple assets at once.
  * The `InputEvents` have been improved:
    * Added `e.IsActionButton` and `e.IsUseToolButton`.
    * Added `ToSButton()` extension for the game's `Game1.options` button type.
    * Deprecated `e.IsClick`, which is limited and unclear. Use `IsActionButton` or `IsUseToolButton` instead.
    * Fixed `e.SuppressButton()` not correctly suppressing keyboard buttons.
    * Fixed `e.IsClick` (now `e.IsActionButton`) ignoring custom key bindings.
  * `SemanticVersion` can now be constructed from a `System.Version`.
  * Fixed reflection API blocking access to some non-SMAPI members.
  * Fixed content API allowing absolute paths as asset keys.
  * Fixed content API failing to load custom map tilesheets that aren't preloaded.
  * Fixed content API incorrectly detecting duplicate loaders when a mod implements `IAssetLoader` directly.

* For SMAPI developers:
  * Added the installer version and platform to the installer window title to simplify troubleshooting.

## 2.0.0
Released 14 October 2017 for Stardew Valley 1.2.30–1.2.33.

### Release highlights
* **Mod update checks**  
  SMAPI now checks if your mods have updates available, and will alert you in the console with a convenient link to the
  mod page. This works with mods from the Chucklefish mod site, GitHub, or Nexus Mods. SMAPI 2.0 launches with
  update-check support for over 250 existing mods, and more will be added as mod authors enable the feature.

* **Mod stability warnings**  
  SMAPI now detects when a mod contains code which can destabilise your game or corrupt your save, and shows a warning
  in the console.

* **Simpler console**  
   The console is now simpler and easier to read, some commands have been streamlined, and the colors now adjust to fit
   your terminal background color.

* **New features for mod authors**  
  SMAPI 2.0 adds several features to enable new kinds of mods (see
  [API documentation](https://stardewvalleywiki.com/Modding:Modder_Guide/APIs)).

  The **content API** lets you edit, inject, and reload XNB data loaded by the game at any time. This lets SMAPI mods do
  anything previously only possible with XNB mods, and enables new mod scenarios not possible with XNB mods (e.g.
  seasonal textures, NPC clothing that depend on the weather or location, etc).

  The **input events** unify controller + keyboard + mouse input into one event and constant for easy handling, and add
  metadata like the cursor position and grab tile to support click handling. They also let you prevent the game from
  receiving input, to enable new scenarios like action highjacking and UI overlays.

  The mod manifest has a few changes too:
  * The **`UpdateKeys` field** lets you specify your Chucklefish, GitHub, or Nexus mod IDs. SMAPI will automatically
    check for newer versions and notify the player.
  * The **version field** is now a semantic string like `"1.0-alpha"`. (Mods which still use the version structure will
    still work fine.)
  * The **dependencies field** now lets you add optional dependencies which should be loaded first if available.

  Finally, the `SDate` utility now has a `DayOfWeek` field for more convenient date calculations, and `ISemanticVersion`
  now implements `IEquatable<ISemanticVersion>`.

* **Goodbye deprecated code**  
  SMAPI 2.0 removes all deprecated code to unshackle future development. That includes...
  * removed all code marked obsolete;
  * removed TrainerMod's `save` and `load` commands;
  * removed support for mods with no `Name`, `Version`, or `UniqueID` in their manifest;
  * removed support for multiple mods having the same `UniqueID` value;
  * removed access to SMAPI internals through the reflection helper.

* **Command-line install**
  For power users and mod managers, the SMAPI installer can now be scripted using command-line arguments
  (see [technical docs](technical/smapi.md#command-line-arguments)).

### Change log
For players:
* SMAPI now alerts you when mods have new versions available.
* SMAPI now warns you about mods which may impact game stability or compatibility.
* The console is now simpler and easier to read, and adjusts its colors to fit your terminal background color.
* Renamed installer folder to avoid confusion.
* Updated compatibility list.
* Fixed update check errors on Linux/macOS.
* Fixed collection-changed errors during startup for some players.

For mod developers:
* Added support for editing, injecting, and reloading XNB data loaded by the game at any time.
* Added support for automatic mod update checks.
* Added unified input events.
* Added support for suppressing input.
* Added support for optional dependencies.
* Added support for specifying the mod version as a string (like `"1.0-alpha"`) in `manifest.json`.
* Added day of week to `SDate` instances.
* Added `IEquatable<ISemanticVersion>` to `ISemanticVersion`.
* Updated Json.NET from 8.0.3 to 10.0.3.
* Removed the TrainerMod's `save` and `load` commands.
* Removed all deprecated code.
* Removed support for mods with no `Name`, `Version`, or `UniqueID` in their manifest.
* Removed support for mods with a non-unique `UniqueID` value in their manifest.
* Removed access to SMAPI internals through the reflection helper, to discourage fragile mods.
* Fixed `SDate.Now()` crashing when called during the new-game intro.
* Fixed `TimeEvents.AfterDayStarted` being raised during the new-game intro.
* Fixed SMAPI allowing map tilesheets with absolute or directory-climbing paths. These are now rejected even if the path exists, to avoid problems when players install the mod.

For power users:
* Added command-line arguments to the SMAPI installer so it can be scripted.

For SMAPI developers:
* Significantly refactored SMAPI to support changes in 2.0 and upcoming releases.
* Overhauled `StardewModdingAPI.config.json` format to support mod data like update keys.
* Removed SMAPI 1._x_ compatibility mode.

## 1.15.4
Released 09 September 2017 for Stardew Valley 1.2.30–1.2.33.

For players:
* Fixed errors when loading some custom maps on Linux/macOS or using XNB Loader.
* Fixed errors in rare cases when a mod calculates an in-game date.

For mod authors:
* Added UTC timestamp to log file.

For SMAPI developers:
* Internal changes to support the upcoming SMAPI 2.0 release.

## 1.15.3
Released 23 August 2017 for Stardew Valley 1.2.30–1.2.33.

For players:
* Fixed mods being wrongly marked as duplicate in some cases.

## 1.15.2
Released 23 August 2017 for Stardew Valley 1.2.30–1.2.33.

For players:
* Improved errors when a mod DLL can't be loaded.
* Improved errors when using very old versions of Stardew Valley.
* Updated compatibility list.

For mod developers:
* Added `Context.CanPlayerMove` property for mod convenience.
* Added content helper properties for the game's current language.
* Fixed `Context.IsPlayerFree` being false if the player is performing an action.
* Fixed `GraphicsEvents.Resize` being raised before the game updates its window data.
* Fixed `SemanticVersion` not being deserializable through Json.NET.
* Fixed terminal not launching on Xfce Linux.

For SMAPI developers:
* Internal changes to support the upcoming SMAPI 2.0 release.

## 1.15.1
Released 10 July 2017 for Stardew Valley 1.2.30–1.2.33.

For players:
* Fixed controller mod input broken in 1.15.
* Fixed TrainerMod packaging unneeded files.

For mod authors:
* Fixed mod registry lookups by unique ID not being case-insensitive.

## 1.15.0
Released 08 July 2017 for Stardew Valley 1.2.30–1.2.31.

For players:
* Cleaned up SMAPI console a bit.
* Revamped TrainerMod's item commands:
  * `player_add` is a new command to add any item to your inventory (including tools, weapons, equipment, craftables, wallpaper, etc). This replaces the former `player_additem`, `player_addring`, and `player_addweapon`.
  * `list_items` now shows all items in the game. You can search by item type like `list_items weapon`, or search by item name like `list_items galaxy sword`.
  * `list_items` now also matches translated item names when playing in another language.
  * `list_item_types` is a new command to see a list of item types.
* Fixed unhelpful error when a `config.json` is invalid.
* Fixed rare crash when window loses focus for a few players (further to fix in 1.14).
* Fixed invalid `ObjectInformation.xnb` causing a flood of warnings; SMAPI now shows one error instead.
* Updated mod compatibility list.

For mod authors:
* Added `SDate` utility for in-game date calculations (see [API reference](https://stardewvalleywiki.com/Modding:Modder_Guide/APIs/Utilities#Dates)).
* Added support for minimum dependency versions in `manifest.json` (see [API reference](https://stardewvalleywiki.com/Modding:Modder_Guide/APIs/Manifest)).
* Added more useful logging when loading mods.
* Added a `ModID` property to all mod helpers for extension methods.
* Changed `manifest.MinimumApiVersion` from string to `ISemanticVersion`. This shouldn't affect mods unless they referenced that field in code.
* Fixed `SemanticVersion` parsing some invalid versions into close approximations (like `1.apple` &rarr; `1.0-apple`).
* Fixed `SemanticVersion` not treating hyphens as separators when comparing prerelease tags.  
  <small>_(While that was technically correct, it leads to unintuitive behaviour like sorting `-alpha-2` _after_ `-alpha-10`, even though `-alpha.2` sorts before `-alpha.10`.)_</small>
* Fixed corrupted state exceptions not being logged by SMAPI.
* Increased all deprecations to _pending removal_.

For SMAPI developers:
* Added SMAPI 2.0 compile mode, for testing how mods will work with SMAPI 2.0.
* Added prototype SMAPI 2.0 feature to override XNB files (not enabled for mods yet).
* Added prototype SMAPI 2.0 support for version strings in `manifest.json` (not recommended for mods yet).
* Compiling SMAPI now uses your `~/stardewvalley.targets` file if present.

## 1.14.0
Released 02 July 2017 for Stardew Valley 1.2.30.

For players:
* SMAPI now shows friendly errors when...
  * it can't detect the game;
  * a mod dependency is missing (if it's listed in the mod manifest);
  * you have Stardew Valley 1.11 or earlier (which aren't compatible);
  * you run `install.exe` from within the downloaded zip file.
* Fixed "unknown mod" deprecation warnings by improving how SMAPI detects the mod using the event.
* Fixed `libgdiplus.dylib` errors for some players on macOS.
* Fixed rare crash when window loses focus for a few players.
* Bumped minimum game version to 1.2.30.
* Updated mod compatibility list.

For mod authors:
* You can now add dependencies to `manifest.json` (see [API reference](https://stardewvalleywiki.com/Modding:Modder_Guide/APIs/Manifest)).
* You can now translate your mod (see [API reference](https://stardewvalleywiki.com/Modding:Modder_Guide/APIs/Translation)).
* You can now load unpacked `.tbin` files from your mod folder through the content API.  
* SMAPI now automatically fixes tilesheet references for maps loaded from the mod folder.  
  <small>_When loading a map from the mod folder, SMAPI will automatically use tilesheets relative to the map file if they exists. Otherwise it will default to tilesheets in the game content._</small>
* Added `Context.IsPlayerFree` for mods that need to check if the player can act (i.e. save is loaded, no menu is displayed, no cutscene is in progress, etc).
* Added `Context.IsInDrawLoop` for specialized mods.
* Fixed `smapi-crash.txt` being copied from the default log even if a different path is specified with `--log-path`.
* Fixed the content API not matching XNB filenames with two dots (like `a.b.xnb`) if you don't specify the `.xnb` extension.
* Fixed `debug` command output not printed to console.
* Deprecated `TimeEvents.DayOfMonthChanged`, `SeasonOfYearChanged`, and `YearOfGameChanged`. These don't do what most mod authors think they do and aren't very reliable, since they depend on the SMAPI/game lifecycle which can change. You should use `TimeEvents.AfterDayStarted` or `SaveEvents.BeforeSave` instead.

## 1.13.1
Released 19 May 2017 for Stardew Valley 1.2.26–1.2.29.

For players:
* Fixed errors when loading a mod with no name or version.
* Fixed mods with no manifest `Name` field having no name (SMAPI will now shows their filename).

## 1.13.0
Released 19 May 2017 for Stardew Valley 1.2.26–1.2.29.

For players:
* SMAPI now recovers better from mod draw errors and detects when the error is irrecoverable.
* SMAPI now recovers automatically from errors in the game loop when possible.
* SMAPI now remembers if your game crashed and offers help next time you launch it.
* Fixed installer sometimes finding redundant game paths.
* Fixed save events not being raised after the first day on Linux/macOS.
* Fixed error on Linux/macOS when a mod loads a PNG immediately after the save is loaded.
* Updated mod compatibility list for Stardew Valley 1.2.

For mod developers:
* Added a `Context.IsWorldReady` flag for mods to use.  
  <small>_This indicates whether a save is loaded and the world is finished initializing, which starts at the same point that `SaveEvents.AfterLoad` and `TimeEvents.AfterDayStarted` are raised. This is mainly useful for events which can be raised before the world is loaded (like update tick)._</small>
* Added a `debug` console command which lets you run the game's debug commands (e.g. `debug warp FarmHouse 1 1` warps you to the farmhouse).
* Added basic context info to logs to simplify troubleshooting.
* Added a `Mod.Dispose` method which can be overriden to clean up before exit. This method isn't guaranteed to be called on every exit.
* Deprecated mods that don't have a `Name`, `Version`, or `UniqueID` in their manifest. These will be required in SMAPI 2.0.
* Deprecated `GameEvents.GameLoaded` and `GameEvents.FirstUpdateTick`. You can move any affected code into your mod's `Entry` method.
* Fixed maps not recognising custom tilesheets added through the SMAPI content API.
* Internal refactoring for upcoming features.

## 1.12.0
Released 03 May 2017 for Stardew Valley 1.2.26–1.2.29.

For players:
* The installer now lets you choose the install path if you have multiple copies of the game, instead of using the first path found.
* Fixed mod draw errors breaking the game.
* Fixed mods on Linux/macOS no longer working after the game saves.
* Fixed `libgdiplus.dylib` errors on macOS when mods read PNG files.
* Adopted pufferchick.

For mod developers:
* Unknown mod manifest fields are now stored in `IManifest::ExtraFields`.
* The content API now defaults to `ContentSource.ModFolder`.
* Fixed content API error when loading a PNG during early game init (e.g. in mod's `Entry`).
* Fixed content API error when loading an XNB from the mod folder on macOS.

## 1.11.0
Released 30 April 2017 for Stardew Valley 1.2.26.

For players:
* SMAPI now detects issues in `ObjectInformation.xnb` files caused by outdated XNB mods.
* Errors when loading a save are now shown in the SMAPI console.
* Improved console logging performance.
* Fixed errors during game update causing the game to hang.
* Fixed errors due to mod events triggering during game save in Stardew Valley 1.2.

For mod developers:
* Added a content API which loads custom textures/maps/data from the mod's folder (`.xnb` or `.png` format) or game content.
* `Console.Out` messages are now written to the log file.
* `Monitor.ExitGameImmediately` now aborts SMAPI initialization and events more quickly.
* Fixed value-changed events being raised when the player loads a save due to values being initialized.

## 1.10.0
Released 24 April 2017 for Stardew Valley 1.2.26.

For players:
* Updated to Stardew Valley 1.2.
* Added logic to rewrite many mods for compatibility with game updates, though some mods may still need an update.
* Fixed `SEHException` errors affecting some players.
* Fixed issue where SMAPI didn't unlock some files on exit.
* Fixed rare issue where the installer would crash trying to delete a bundled mod from `%appdata%`.
* Improved TrainerMod commands:
  * Added `world_setyear` to change the current year.
  * Replaced `player_addmelee` with `player_addweapon` with support for non-melee weapons.

For mod developers:
* Mods are now initialized after the `Initialize`/`LoadContent` phase, which means the `GameEvents.Initialize` and `GameEvents.LoadContent` events are deprecated. You can move any logic in those methods to your mod's `Entry` method.
* Added `IsBetween` and string overloads to the `ISemanticVersion` methods.
* Fixed mouse-changed event never updating prior mouse position.
* Fixed `monitor.ExitGameImmediately` not working correctly.
* Fixed `Constants.SaveFolderName` not set for a new game until the save is created.

## 1.9.0
Released 05 April 2017 for Stardew Valley 1.1–1.11.

For players:
* SMAPI now detects incompatible mods and disables them before they cause problems.
* SMAPI now allows mods nested into an otherwise empty parent folder (like `Mods\ModName-1.0\ModName\manifest.json`), since that's a common default behaviour when unpacking mods.
* The installer now detects if you need to update .NET Framework before installing SMAPI.
* The installer now detects if you need to run the game at least once (to let it perform first-time setup) before installing SMAPI.
* The installer on Linux now finds games installed to `~/.steam/steam/steamapps/common/Stardew Valley` too.
* The installer now removes old SMAPI logs to prevent confusion.
* The console now has simpler error messages.
* The console now has improved command handling & feedback.
* The console no longer shows the game's debug output (unless you use a _SMAPI for developers_ build).
* Fixed the game-needs-an-update error not pausing before exit.
* Fixed installer errors for some players when deleting files.
* Fixed installer not ignoring potential game folders that don't contain a Stardew Valley exe.
* Fixed installer not recognising Linux/macOS paths starting with `~/` or containing an escaped space.
* Fixed TrainerMod letting you add invalid items which may crash the game.
* Fixed TrainerMod's `world_downminelevel` command not working.
* Fixed rare issue where mod dependencies would override SMAPI dependencies and cause unpredictable bugs.
* Fixed errors in mods' console command handlers crashing the game.

For mod developers:
* Added a simpler API for console commands (see `helper.ConsoleCommands`).
* Added `TimeEvents.AfterDayStarted` event triggered when a day starts. This happens no matter how the day started (including new game, loaded save, or player went to bed).
* Added `ContentEvents.AfterLocaleChanged` event triggered when the player changes the content language (for the upcoming Stardew Valley 1.2).
* Added `SaveEvents.AfterReturnToTitle` event triggered when the player returns to the title screen (for the upcoming Stardew Valley 1.2).
* Added `helper.Reflection.GetPrivateProperty` method.
* Added a `--log-path` argument to specify the SMAPI log path during testing.
* SMAPI now writes XNA input enums (`Buttons` and `Keys`) to JSON as strings automatically, so mods no longer need to add a `StringEnumConverter` themselves for those.
* The SMAPI log now has a simpler filename.
* The SMAPI log now shows the OS caption (like "Windows 10") instead of its internal version when available.
* The SMAPI log now always uses `\r\n` line endings to simplify crossplatform viewing.
* Fixed `SaveEvents.AfterLoad` being raised during the new-game intro before the player is initialized.
* Fixed SMAPI not recognising `Mod` instances that don't subclass `Mod` directly.
* Several obsolete APIs have been removed (see [migration guides](https://stardewvalleywiki.com/Modding:Index#Migration_guides)),
  and all _notice_-level deprecations have been increased to _info_.
* Removed the experimental `IConfigFile`.

For SMAPI developers:
* Added support for debugging SMAPI on Linux/macOS if supported by the editor.

## 1.8.0
Released 04 February 2017 for Stardew Valley 1.1–1.11.

For players:
* Mods no longer generate `.cache` subfolders.
* Fixed multiple issues where mods failed during assembly loading.
* Tweaked install package to reduce confusion.

For mod developers:
* The `SemanticVersion` constructor now accepts a string version.
* Increased deprecation level for `Extensions` to _pending removal_.
* **Warning:** `Assembly.GetExecutingAssembly().Location` will no longer reliably
  return a valid path, because mod assemblies are loaded from memory when rewritten for
  compatibility. This approach has been discouraged since SMAPI 1.3; use `helper.DirectoryPath`
  instead.

For SMAPI developers:
* Rewrote assembly loading from the ground up. The new implementation...
  * is much simpler;
  * eliminates the `.cache` folders by loading rewritten assemblies from memory;
  * ensures DLLs are loaded in leaf-to-root order (i.e. dependencies first);
  * improves dependent assembly resolution;
  * no longer loads DLLs if they're not referenced;
  * reduces log verbosity.

## 1.7.0
Released 19 January 2017 for Stardew Valley 1.1–1.11.

For players:
* The console now shows the folder path where mods should be added.
* The console now shows deprecation warnings after the list of loaded mods (instead of intermingled).

For mod developers:
* Added a mod registry which provides metadata about loaded mods.
* The `Entry(…)` method is now deferred until all mods are loaded.
* Fixed `SaveEvents.BeforeSave` and `.AfterSave` not triggering on days when the player shipped something.
* Fixed `PlayerEvents.LoadedGame` and `SaveEvents.AfterLoad` being fired before the world finishes initializing.
* Fixed some `LocationEvents`, `PlayerEvents`, and `TimeEvents` being fired during game startup.
* Increased deprecation levels for `SObject`, `LogWriter` (not `Log`), and `Mod.Entry(ModHelper)` (not `Mod.Entry(IModHelper)`) to _pending removal_. Increased deprecation levels for `Mod.PerSaveConfigFolder`, `Mod.PerSaveConfigPath`, and `Version.VersionString` to _info_.

## 1.6.0
Released 16 January 2017 for Stardew Valley 1.1–1.11.

For players:
* Added console commands to open the game/data folders.
* Updated list of incompatible mods.
* Fixed `config.json` values being duplicated in some cases.
* Fixed some Linux users not being able to launch SMAPI from Steam.
* Fixed the installer not finding custom install paths on 32-bit Windows.
* Fixed error when loading a mod which was released with a `.cache` folder for a different platform.
* Fixed error when the console doesn't support colour.
* Fixed error when a mod reads a custom JSON file from a directory that doesn't exist.

For mod developers:
* Added three events: `SaveEvents.BeforeSave`, `SaveEvents.AfterSave`, and `SaveEvents.AfterLoad`.
* Deprecated three events:
  * `TimeEvents.OnNewDay` is unreliable; use `TimeEvents.DayOfMonthChanged` or `SaveEvents` instead.
  * `PlayerEvents.LoadedGame` is replaced by `SaveEvents.AfterLoad`.
  * `PlayerEvents.FarmerChanged` serves no purpose.

For SMAPI developers:
  * Added support for specifying a lower bound in mod incompatibility data.
  * Added support for custom incompatible-mod error text.
  * Fixed issue where `TrainerMod` used older logic to detect the game path.

## 1.5.0
Released 27 December 2016 for Stardew Valley 1.1–1.11.

For players:
  * Added an option to disable update checks.
  * SMAPI will now show a friendly error with update links when you try to use a known incompatible mod version.
  * Fixed an error when a mod uses the new reflection API on a missing field or method.
  * Fixed an issue where mods weren't notified of a menu change if it changed while SMAPI was still notifying mods of the previous change.

For developers:
  * Deprecated `Version` in favour of `SemanticVersion`.  
    _This new implementation is [semver 2.0](https://semver.org/)-compliant, introduces `NewerThan(version)` and `OlderThan(version)` convenience methods, adds support for parsing a version string into a `SemanticVersion`, and fixes various bugs with the former implementation. This also replaces `Manifest` with `IManifest`._
  * Increased deprecation levels for `SObject`, `Extensions`, `LogWriter` (not `Log`), `SPlayer`, and `Mod.Entry(ModHelper)` (not `Mod.Entry(IModHelper)`).

## 1.4.0
Released 12 December 2016 for Stardew Valley 1.1–1.11.

For players:
  * SMAPI will now prevent mods from crashing your game with menu errors.
  * The installer will now automatically detect most custom install paths.
  * The installer will now automatically clean up old SMAPI files.
  * Each mod now has its own `.cache` folder, so removing the mod won't leave orphaned cache files behind.
  * Improved installer wording to reduce confusion.
  * Fixed the installer not removing TrainerMod from appdata if it's already in the game mods directory.
  * Fixed the installer not moving mods out of appdata if the game isn't installed on the same Windows partition.
  * Fixed the SMAPI console not being shown on Linux and macOS.

For developers:
  * Added a reflection API (via `helper.Reflection`) that simplifies robust access to the game's private fields and methods.
  * Added a searchable `list_items` console command to replace the `out_items`, `out_melee`, and `out_rings` commands.
  * Added `TypeLoadException` details when intercepted by SMAPI.
  * Fixed an issue where you couldn't debug into an assembly because it was copied into the `.cache` directory. That will now only happen if necessary.

## 1.3.0
Released 04 December 2016 for Stardew Valley 1.1–1.11.

For players:
  * You can now run most mods on any platform (e.g. run Windows mods on Linux/macOS).
  * Fixed the normal uninstaller not removing files added by the 'SMAPI for developers' installer.

## 1.2.0
Released 25 November 2016 for Stardew Valley 1.1–1.11.

For players:
  * Fixed compatibility with some older mods.
  * Fixed mod errors in most event handlers crashing the game.
  * Fixed mod errors in some event handlers preventing other mods from receiving the same event.
  * Fixed game crashing on startup with an audio error for some players.

For developers:
  * Improved logging to show `ReflectionTypeLoadException` details when it's caught by SMAPI.

## 1.1.1
Released 19 November 2016 for Stardew Valley 1.1–1.11.

For players:
  * Fixed compatibility with some older mods.
  * Fixed race condition where some mods would sometimes crash because the game wasn't ready yet.

For developers:
  * Fixed deprecation warnings being repeated if the mod can't be identified.

## 1.1.0
Released 17 November 2016 for Stardew Valley 1.1–1.11.

For players:
  * Fixed console exiting immediately when some exceptions occur.
  * Fixed an error in 1.0 when mod uses `config.json` but the file doesn't exist.
  * Fixed critical errors being saved to a separate log file.

For developers:
  * Added new logging interface:
    * easier to use;
    * supports trace logs (written to the log file, but hidden in the console by default);
    * messages are now listed in order;
    * messages now show which mod logged them;
    * more consistent and intuitive console color scheme.
  * Added optional `MinimumApiVersion` to `manifest.json`.
  * Added emergency interrupt feature for dangerous mods.

## 1.0.0
Released 11 November 2016 for Stardew Valley 1.1–1.11.

For players:
  * Added support for Linux and macOS.
  * Added installer to automate adding & removing SMAPI.
  * Added background update check on launch.
  * Fixed missing `steam_appid.txt` file.
  * Fixed some mod UIs disappearing at a non-default zoom level for some users.
  * Removed undocumented support for mods in AppData folder **(breaking change)**.
  * Removed `F2` debug mode.

For mod developers:
  * Added deprecation warnings.
  * Added OS version to log.
  * Added zoom-adjusted mouse position to mouse-changed event arguments.
  * Added SMAPI code documentation.
  * Switched to [semantic versioning](https://semver.org).
  * Fixed mod versions not shown correctly in the log.
  * Fixed misspelled field in `manifest.json` schema.
  * Fixed some events getting wrong data.
  * Simplified log output.

For SMAPI developers:
  * Simplified compiling from source.
  * Formalised release process and added automated build packaging.
  * Removed obsolete and unfinished code.
  * Internal cleanup & refactoring.

## 0.x
* 0.40.1.1 (30 September 2016)
  * Added support for Stardew Valley 1.1.
* 0.40.0 (05 April 2016)
  * Fixed an error that ocurred during minigames.
* 0.39.7 (04 April 2016)
  * Added 'no check' graphics events that are triggered regardless of game's if checks.
* 0.39.6 (01 April 2016)
  * Added game & SMAPI versions to log.
  * Fixed conflict in graphics tick events.
  * Bug fixes.
* 0.39.5 (30 March 2016)
* 0.39.4 (29 March 2016)
* 0.39.3 (28 March 2016)
* 0.39.2 (23 March 2016)
* 0.39.1 (23 March 2016)
* 0.38.8 (23 March 2016)
* 0.38.7 (23 March 2016)
* 0.38.6 (22 March 2016)
* 0.38.5 (22 March 2016)
* 0.38.4 (21 March 2016)
* 0.38.3 (21 March 2016)
* 0.38.2 (21 March 2016)
* 0.38.0 (20 March 2016)
* 0.38.1 (20 March 2016)
* 0.37.3 (08 March 2016)
* 0.37.2 (07 March 2016)
* 0.37.1 (06 March 2016)
* 0.36 (04 March 2016)
* 0.37 (04 March 2016)
* 0.35 (02 March 2016)
* 0.34 (02 March 2016)
* 0.33 (02 March 2016)
* 0.32 (02 March 2016)
* 0.31 (02 March 2016)
* 0.3 (01 March 2016)
* 0.2 (29 February 2016)
* 0.1 (28 February 2016)
